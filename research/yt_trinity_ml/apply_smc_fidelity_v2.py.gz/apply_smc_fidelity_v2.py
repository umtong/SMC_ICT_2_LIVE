from __future__ import annotations

from pathlib import Path

ROOT = Path('.')
CORPUS = ROOT / 'research/yt_trinity_ml/system/corpus_alpha.py'
TESTS = ROOT / 'research/yt_trinity_ml/tests/test_corpus_alpha.py'


def replace_once(path: Path, old: str, new: str, label: str) -> None:
    text = path.read_text(encoding='utf-8')
    count = text.count(old)
    if count != 1:
        raise SystemExit(f'{label}: expected exactly one match, found {count}')
    path.write_text(text.replace(old, new), encoding='utf-8')


replace_once(
    CORPUS,
    '''    liquidity_quality: int\n    phase: str = "AWAIT_DISPLACEMENT"\n''',
    '''    liquidity_quality: int\n    ob_search_start: int | None = None\n    raid_reclaimed_same_bar: bool = False\n    phase: str = "AWAIT_DISPLACEMENT"\n''',
    'narrative provenance fields',
)
replace_once(
    CORPUS,
    '''    first_retest_pos: int | None = None\n    retest_trigger: float | None = None\n    retest_extreme: float | None = None\n''',
    '''    first_retest_pos: int | None = None\n    mitigation_count: int = 0\n    retest_trigger: float | None = None\n    retest_extreme: float | None = None\n    entry_confirmation_kind: int = 0\n''',
    'mitigation and confirmation fields',
)
replace_once(
    CORPUS,
    '''def _numeric_row(row: pd.Series) -> dict[str, float]:\n    result: dict[str, float] = {}\n    for key, value in row.items():\n        if isinstance(value, (int, float, np.integer, np.floating)) and np.isfinite(value):\n            result[str(key)] = float(value)\n    return result\n''',
    '''def _numeric_row(row: pd.Series) -> dict[str, float]:\n    """Return only causal, scale-free context for the pooled cross-symbol ML model.\n\n    Absolute OHLC, raw volume and price-level columns let a pooled tree identify the\n    instrument and calendar regime instead of learning SMC setup quality. Structural\n    distances are added separately in ATR/R units below.\n    """\n\n    raw_exact = {\n        "open", "high", "low", "close", "volume", "turnover", "trade_count",\n        "buy_volume", "sell_volume", "open_interest", "mark_price", "index_price",\n    }\n    raw_suffixes = (\n        "_price", "_level", "_lower", "_upper", "_equilibrium",\n        "_high", "_low", "_open", "_close", "_volume", "_turnover",\n        "_trade_count", "_open_interest",\n    )\n    result: dict[str, float] = {}\n    for key, value in row.items():\n        name = str(key)\n        if not isinstance(value, (int, float, np.integer, np.floating)) or not np.isfinite(value):\n            continue\n        if name in raw_exact or "timestamp" in name or name.endswith(("_ns", "_ms")):\n            continue\n        if name.endswith(raw_suffixes):\n            continue\n        result[name] = float(value)\n    return result\n''',
    'scale-free pooled features',
)
replace_once(
    CORPUS,
    '''def _pool_key(pool: _LiquidityPool) -> tuple[str, float]:\n    # Pool source labels can gain confluence later; consumption identity is price-based.\n    # Log-price quantization is scale-free across BTC, ETH, SOL and XRP.\n    return "LEVEL", round(float(np.log(pool.price)), 4)\n''',
    '''def _pool_key(pool: _LiquidityPool) -> tuple[str, float]:\n    # A touch of an internal swing must not permanently consume a later PDH/PWH or\n    # session pool merely because it formed at approximately the same price. Keep\n    # source provenance and use fine scale-free log-price quantization.\n    provenance = "+".join(sorted(part for part in pool.kind.split("+") if part)) or "LEVEL"\n    return provenance, round(float(np.log(pool.price)), 6)\n''',
    'liquidity consumption identity',
)
replace_once(
    CORPUS,
    '''    ob_start = state.created_pos if state.created_pos < pos else max(0, pos - 12)\n    ob = _order_block_zone(features, ob_start, pos, state.side)\n''',
    '''    if state.ob_search_start is not None:\n        ob_start = int(state.ob_search_start)\n    else:\n        ob_start = state.created_pos if state.created_pos < pos else max(0, pos - 12)\n    ob_start = max(0, min(ob_start, max(0, pos - 1)))\n    ob = _order_block_zone(features, ob_start, pos, state.side)\n''',
    'protected-swing OB origin',
)
replace_once(
    CORPUS,
    '''def _entry_confirmation(\n    state: _NarrativeState,\n    row: pd.Series,\n    previous: pd.Series,\n    config: CorpusAlphaConfig,\n) -> bool:\n    midpoint = (float(state.zone_lower) + float(state.zone_upper)) / 2.0\n    close = float(row["close"])\n    body = float(row.get("body_atr", 0.0)) if _finite(row.get("body_atr")) else 0.0\n    location = float(row.get("close_location", 0.5)) if _finite(row.get("close_location")) else 0.5\n    if state.side > 0:\n        same_bar_rejection = close > float(state.zone_upper) and body > 0 and location >= config.entry_close_location\n        later_cisd = (\n            state.first_retest_pos is not None\n            and close > max(float(state.retest_trigger or midpoint), float(previous["high"]))\n            and body > 0\n        )\n        return bool(same_bar_rejection or later_cisd)\n    same_bar_rejection = close < float(state.zone_lower) and body < 0 and location <= 1.0 - config.entry_close_location\n    later_cisd = (\n        state.first_retest_pos is not None\n        and close < min(float(state.retest_trigger or midpoint), float(previous["low"]))\n        and body < 0\n    )\n    return bool(same_bar_rejection or later_cisd)\n''',
    '''def _entry_confirmation(\n    state: _NarrativeState,\n    row: pd.Series,\n    previous: pd.Series,\n    config: CorpusAlphaConfig,\n) -> int:\n    """Return 0=no entry, 1=zone rejection, 2=later CISD confirmation."""\n\n    midpoint = (float(state.zone_lower) + float(state.zone_upper)) / 2.0\n    close = float(row["close"])\n    body = float(row.get("body_atr", 0.0)) if _finite(row.get("body_atr")) else 0.0\n    location = float(row.get("close_location", 0.5)) if _finite(row.get("close_location")) else 0.5\n    if state.side > 0:\n        same_bar_rejection = close > float(state.zone_upper) and body > 0 and location >= config.entry_close_location\n        later_cisd = (\n            state.first_retest_pos is not None\n            and close > max(float(state.retest_trigger or midpoint), float(previous["high"]))\n            and body > 0\n        )\n    else:\n        same_bar_rejection = close < float(state.zone_lower) and body < 0 and location <= 1.0 - config.entry_close_location\n        later_cisd = (\n            state.first_retest_pos is not None\n            and close < min(float(state.retest_trigger or midpoint), float(previous["low"]))\n            and body < 0\n        )\n    if same_bar_rejection:\n        return 1\n    if later_cisd:\n        return 2\n    return 0\n''',
    'typed post-mitigation confirmation',
)
replace_once(
    CORPUS,
    '''            "liquidity_quality": float(state.liquidity_quality),\n            "draw_target_quality": float(state.draw_target_quality),\n''',
    '''            "liquidity_quality": float(state.liquidity_quality),\n            "raid_reclaimed_same_bar": float(state.raid_reclaimed_same_bar),\n            "draw_target_quality": float(state.draw_target_quality),\n            "ob_search_age_bars": float(\n                max(\n                    0,\n                    int(state.confirmation_pos or pos)\n                    - int(state.ob_search_start if state.ob_search_start is not None else state.created_pos),\n                )\n            ),\n''',
    'setup provenance features',
)
replace_once(
    CORPUS,
    '''            "retest_wait_bars": float(pos - int(state.first_retest_pos or pos)),\n            "stop_distance_atr": stop_distance / atr,\n''',
    '''            "retest_wait_bars": float(pos - int(state.first_retest_pos or pos)),\n            "mitigation_count": float(state.mitigation_count),\n            "entry_confirmation_kind": float(state.entry_confirmation_kind),\n            "stop_distance_atr": stop_distance / atr,\n''',
    'mitigation quality features',
)
replace_once(
    CORPUS,
    '''    if touched:\n        if state.first_retest_pos is None:\n''',
    '''    if touched:\n        state.mitigation_count += 1\n        if state.first_retest_pos is None:\n''',
    'mitigation counting',
)
replace_once(
    CORPUS,
    '''    if _entry_confirmation(state, row, previous, config):\n        event = _event_from_state(state, row, timestamp, symbol, pos)\n        if event is not None:\n            _bump(diagnostics, "entry_confirmations")\n        return None, event\n''',
    '''    confirmation_kind = _entry_confirmation(state, row, previous, config)\n    if confirmation_kind:\n        state.entry_confirmation_kind = confirmation_kind\n        event = _event_from_state(state, row, timestamp, symbol, pos)\n        if event is not None:\n            _bump(diagnostics, "entry_confirmations")\n            _bump(\n                diagnostics,\n                "zone_rejection_entries" if confirmation_kind == 1 else "later_cisd_entries",\n            )\n        return None, event\n''',
    'confirmation diagnostics',
)
replace_once(
    CORPUS,
    '''        if _pool_key(pool) not in consumed_high\n        and float(row["high"]) > pool.price + buffer\n        and float(row["close"]) < pool.price\n''',
    '''        if _pool_key(pool) not in consumed_high\n        and float(row["high"]) > pool.price + buffer\n''',
    'high raid without forced same-bar reclaim',
)
replace_once(
    CORPUS,
    '''        if _pool_key(pool) not in consumed_low\n        and float(row["low"]) < pool.price - buffer\n        and float(row["close"]) > pool.price\n''',
    '''        if _pool_key(pool) not in consumed_low\n        and float(row["low"]) < pool.price - buffer\n''',
    'low raid without forced same-bar reclaim',
)
replace_once(
    CORPUS,
    '''                    liquidity_quality=selected.quality,\n                    stop=float(row["high"] + config.stop_buffer_atr * atr),\n''',
    '''                    liquidity_quality=selected.quality,\n                    raid_reclaimed_same_bar=bool(float(row["close"]) < selected.price),\n                    stop=float(row["high"] + config.stop_buffer_atr * atr),\n''',
    'short raid reclaim metadata',
)
replace_once(
    CORPUS,
    '''                    liquidity_quality=selected.quality,\n                    stop=float(row["low"] - config.stop_buffer_atr * atr),\n''',
    '''                    liquidity_quality=selected.quality,\n                    raid_reclaimed_same_bar=bool(float(row["close"]) > selected.price),\n                    stop=float(row["low"] - config.stop_buffer_atr * atr),\n''',
    'long raid reclaim metadata',
)
replace_once(
    CORPUS,
    '''def _new_continuation_state(\n''',
    '''def _last_level_origin_pos(\n    features: pd.DataFrame,\n    pos: int,\n    value: float,\n    side: int,\n) -> int:\n    """Locate the protected swing that owns a continuation OB search window."""\n\n    segment = features.iloc[: pos + 1]\n    series = segment["low"] if side > 0 else segment["high"]\n    atr = float(features.iloc[pos]["atr"])\n    tolerance = max(0.15 * atr, abs(float(value)) * 1e-8, 1e-12)\n    matches = np.flatnonzero((series - float(value)).abs().le(tolerance).to_numpy())\n    if len(matches):\n        return int(matches[-1])\n    return max(0, pos - 12)\n\n\ndef _new_continuation_state(\n''',
    'protected swing origin helper',
)
replace_once(
    CORPUS,
    '''    if not _finite(stop_anchor):\n        stop_anchor = float(row["low"] if side > 0 else row["high"])\n    state = _NarrativeState(\n''',
    '''    if not _finite(stop_anchor):\n        stop_anchor = float(row["low"] if side > 0 else row["high"])\n    ob_search_start = _last_level_origin_pos(features, pos, float(stop_anchor), side)\n    state = _NarrativeState(\n''',
    'continuation protected swing lookup',
)
replace_once(
    CORPUS,
    '''        liquidity_quality=0,\n        path_high=float(row["high"]),\n''',
    '''        liquidity_quality=0,\n        ob_search_start=ob_search_start,\n        path_high=float(row["high"]),\n''',
    'continuation OB provenance',
)

marker = 'def test_reversal_can_confirm_after_raid_without_same_bar_reclaim() -> None:'
text = TESTS.read_text(encoding='utf-8')
if marker in text:
    raise SystemExit('fidelity regression tests already present')
text += '''\n\n\ndef test_reversal_can_confirm_after_raid_without_same_bar_reclaim() -> None:\n    frame = _features(\n        [\n            {"high": 101, "low": 99, "close": 100},\n            {"high": 102, "low": 99, "close": 101},\n            {"high": 104, "low": 100, "close": 103},\n            {\n                "open": 104, "high": 106, "low": 103, "close": 105.5,\n                "micro_last_swing_low": 100, "last_swing_high": 105,\n            },\n            {\n                "open": 105.5, "high": 105.8, "low": 98, "close": 99,\n                "body_atr": -6.5, "range_atr": 7.8, "close_location": 0.13,\n                "bear_fvg_lower": 102, "bear_fvg_upper": 103, "last_swing_low": 95,\n            },\n            {\n                "open": 102.0, "high": 102.7, "low": 101.8, "close": 102.4,\n                "body_atr": 0.4, "range_atr": 0.9, "close_location": 0.67,\n            },\n            {\n                "open": 102.2, "high": 102.3, "low": 100.7, "close": 101.0,\n                "body_atr": -1.2, "range_atr": 1.6, "close_location": 0.19,\n            },\n        ]\n    )\n    events = generate_corpus_candidates(frame, "BTCUSDT")\n    assert len(events) == 1\n    event = events[0]\n    assert event.timestamp == frame.index[6]\n    assert event.feature_row["raid_reclaimed_same_bar"] == 0.0\n    assert event.feature_row["entry_confirmation_kind"] == 1.0\n    assert event.feature_row["mitigation_count"] >= 1.0\n\n\ndef test_pooled_ml_feature_row_excludes_raw_absolute_prices_and_volume() -> None:\n    frame = _features(\n        [\n            {"high": 101, "low": 99, "close": 100},\n            {"high": 102, "low": 99, "close": 101},\n            {"high": 104, "low": 100, "close": 103},\n            {"open": 104, "high": 106, "low": 102, "close": 104, "micro_last_swing_low": 100},\n            {\n                "open": 104, "high": 104.2, "low": 98, "close": 99,\n                "body_atr": -5.0, "range_atr": 6.2, "close_location": 0.16,\n                "bear_fvg_lower": 102, "bear_fvg_upper": 103,\n            },\n            {\n                "open": 102.4, "high": 102.8, "low": 101.5, "close": 101.6,\n                "body_atr": -0.8, "range_atr": 1.3, "close_location": 0.08,\n            },\n        ]\n    )\n    event = generate_corpus_candidates(frame, "BTCUSDT")[0]\n    for forbidden in (\n        "open", "high", "low", "close", "volume", "previous_day_high",\n        "previous_week_low", "micro_last_swing_high", "bear_fvg_lower",\n    ):\n        assert forbidden not in event.feature_row\n    assert "body_atr" in event.feature_row\n    assert "raw_structural_reward_risk" in event.feature_row\n\n\ndef test_liquidity_consumption_identity_preserves_source_provenance() -> None:\n    from system.corpus_alpha import _LiquidityPool, _pool_key\n\n    internal = _LiquidityPool(price=100.0, quality=2, kind="INTERNAL_BSL")\n    external = _LiquidityPool(price=100.0, quality=6, kind="PDH")\n    assert _pool_key(internal) != _pool_key(external)\n\n\ndef test_continuation_ob_search_begins_at_protected_swing() -> None:\n    from system.corpus_alpha import _last_level_origin_pos, _order_block_zone\n\n    frame = _features(\n        [\n            {"open": 110, "high": 111, "low": 108, "close": 109},\n            {"open": 109, "high": 110, "low": 98, "close": 108},\n            {"open": 99, "high": 101, "low": 98, "close": 100},\n            {"open": 100, "high": 102, "low": 99, "close": 101},\n            {"open": 101, "high": 105, "low": 101, "close": 104},\n        ]\n    )\n    origin = _last_level_origin_pos(frame, 4, 98.0, 1)\n    assert origin == 2\n    assert _order_block_zone(frame, origin, 4, 1) is None\n'''
TESTS.write_text(text, encoding='utf-8')
