from __future__ import annotations

import hashlib
from pathlib import Path

import archive_source
import run_screen


def archive_source_bundle(session, cache, start_ms, end_ms):
    panels = {}
    funding = {}
    manifest = []
    for pair in run_screen.PAIRS:
        frames, curve_manifest = archive_source.fetch_curve_frames(
            session,
            cache / "official_archive",
            pair,
            run_screen.INTERVAL,
            start_ms,
            end_ms,
        )
        funding_frame, funding_manifest = archive_source.fetch_funding(
            session,
            cache / "official_archive",
            pair,
            start_ms,
            end_ms,
        )
        panels[pair] = run_screen.build_pair_panel(frames, pair)
        funding[pair] = funding_frame
        manifest.extend(curve_manifest)
        manifest.extend(funding_manifest)
    manifest.append(
        {
            "source_transport": "official Binance monthly public archives with CHECKSUM and deterministic dated-contract stitch",
            "wrapper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "archive_source_sha256": hashlib.sha256(
                Path(archive_source.__file__).read_bytes()
            ).hexdigest(),
            "rest_source_blocked_attempt": "GitHub-hosted REST returned 451/202 before any market row; no 2024 outcome was requested",
        }
    )
    return panels, funding, manifest


run_screen.source_bundle = archive_source_bundle

if __name__ == "__main__":
    raise SystemExit(run_screen.main())
