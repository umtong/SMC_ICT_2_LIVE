from __future__ import annotations

import hashlib
import io
import json
import math
import re
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
import requests

UTC = timezone.utc
ARCHIVE_BASES = (
    "https://data.binance.vision/",
    "https://s3-ap-northeast-1.amazonaws.com/data.binance.vision/",
)
KLINE_COLUMNS = [
    "open_time_ms",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "close_time_ms",
    "quote_volume",
    "trade_count",
    "taker_base_volume",
    "taker_quote_volume",
    "ignore",
]


class ArchiveSourceError(RuntimeError):
    pass


class ArchiveMissing(ArchiveSourceError):
    pass


@dataclass(frozen=True, slots=True)
class ArchiveObject:
    key: str
    url: str
    sha256: str
    bytes: int
    checksum_url: str
    checksum_text: str
    cache_hit: bool


def _sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _month_floor(value: datetime) -> datetime:
    return datetime(value.year, value.month, 1, tzinfo=UTC)


def _next_month(value: datetime) -> datetime:
    if value.month == 12:
        return datetime(value.year + 1, 1, 1, tzinfo=UTC)
    return datetime(value.year, value.month + 1, 1, tzinfo=UTC)


def month_starts(start_ms: int, end_ms: int) -> list[datetime]:
    start = datetime.fromtimestamp(start_ms / 1000, tz=UTC)
    end = datetime.fromtimestamp((end_ms - 1) / 1000, tz=UTC)
    cursor = _month_floor(start)
    finish = _month_floor(end)
    values: list[datetime] = []
    while cursor <= finish:
        values.append(cursor)
        cursor = _next_month(cursor)
    return values


def last_friday(year: int, month: int) -> datetime:
    next_month = (
        datetime(year + 1, 1, 1, 8, tzinfo=UTC)
        if month == 12
        else datetime(year, month + 1, 1, 8, tzinfo=UTC)
    )
    value = next_month - timedelta(days=1)
    while value.weekday() != 4:
        value -= timedelta(days=1)
    return value


def quarter_expiries(start_ms: int, end_ms: int) -> list[datetime]:
    start_year = datetime.fromtimestamp(start_ms / 1000, tz=UTC).year - 1
    end_year = datetime.fromtimestamp((end_ms - 1) / 1000, tz=UTC).year + 2
    values = [
        last_friday(year, month)
        for year in range(start_year, end_year + 1)
        for month in (3, 6, 9, 12)
    ]
    return sorted(values)


def contract_symbols_for_month(
    pair: str,
    month_start: datetime,
    expiries: list[datetime],
) -> list[tuple[str, int]]:
    month_end = _next_month(month_start)
    anchors = (month_start, month_end - timedelta(milliseconds=1))
    selected: dict[int, str] = {}
    for anchor in anchors:
        future = [expiry for expiry in expiries if expiry > anchor]
        for expiry in future[:2]:
            expiry_ms = int(expiry.timestamp() * 1000)
            selected[expiry_ms] = f"{pair}_{expiry:%y%m%d}"
    return [(symbol, expiry_ms) for expiry_ms, symbol in sorted(selected.items())]


def _request_bytes(
    session: requests.Session,
    url: str,
    *,
    allow_missing: bool,
    timeout: float = 60.0,
) -> bytes:
    errors: list[str] = []
    for attempt in range(4):
        try:
            response = session.get(url, timeout=timeout)
        except requests.RequestException as exc:
            errors.append(f"network {type(exc).__name__}: {exc}")
            continue
        if response.status_code == 200:
            return response.content
        if response.status_code in {403, 404} and allow_missing:
            raise ArchiveMissing(f"missing archive object: {url} status={response.status_code}")
        errors.append(f"status={response.status_code} body={response.text[:300]}")
    raise ArchiveSourceError(f"archive request failed {url}: {' | '.join(errors)}")


def download_verified_archive(
    session: requests.Session,
    cache: Path,
    key: str,
    *,
    allow_missing: bool = False,
) -> tuple[Path, ArchiveObject]:
    cache_path = cache / key
    meta_path = cache_path.with_suffix(cache_path.suffix + ".meta.json")
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    if cache_path.exists() and meta_path.exists():
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        actual = _file_sha256(cache_path)
        if actual == meta.get("sha256"):
            return cache_path, ArchiveObject(
                key=key,
                url=meta["url"],
                sha256=actual,
                bytes=int(cache_path.stat().st_size),
                checksum_url=meta["checksum_url"],
                checksum_text=meta["checksum_text"],
                cache_hit=True,
            )
        cache_path.unlink(missing_ok=True)
        meta_path.unlink(missing_ok=True)

    missing_count = 0
    failures: list[str] = []
    for base in ARCHIVE_BASES:
        url = base + key
        checksum_url = url + ".CHECKSUM"
        try:
            checksum_payload = _request_bytes(
                session, checksum_url, allow_missing=allow_missing
            )
            archive_payload = _request_bytes(session, url, allow_missing=allow_missing)
        except ArchiveMissing as exc:
            missing_count += 1
            failures.append(str(exc))
            continue
        except ArchiveSourceError as exc:
            failures.append(str(exc))
            continue
        checksum_text = checksum_payload.decode("utf-8", errors="strict").strip()
        match = re.search(r"\b([0-9a-fA-F]{64})\b", checksum_text)
        if not match:
            failures.append(f"invalid checksum payload {checksum_url}: {checksum_text[:200]}")
            continue
        expected = match.group(1).lower()
        actual = _sha256_bytes(archive_payload)
        if actual != expected:
            failures.append(
                f"checksum mismatch {url}: expected={expected} actual={actual}"
            )
            continue
        temporary = cache_path.with_suffix(cache_path.suffix + ".tmp")
        temporary.write_bytes(archive_payload)
        temporary.replace(cache_path)
        meta = {
            "key": key,
            "url": url,
            "checksum_url": checksum_url,
            "checksum_text": checksum_text,
            "sha256": actual,
            "bytes": len(archive_payload),
        }
        meta_path.write_text(
            json.dumps(meta, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        return cache_path, ArchiveObject(
            key=key,
            url=url,
            sha256=actual,
            bytes=len(archive_payload),
            checksum_url=checksum_url,
            checksum_text=checksum_text,
            cache_hit=False,
        )
    if allow_missing and missing_count == len(ARCHIVE_BASES):
        raise ArchiveMissing(f"archive missing across mirrors: {key}")
    raise ArchiveSourceError(
        f"verified archive unavailable {key}: {' | '.join(failures[-6:])}"
    )


def _read_zip_csv(path: Path) -> pd.DataFrame:
    with zipfile.ZipFile(path) as archive:
        names = [
            name
            for name in archive.namelist()
            if not name.endswith("/") and name.lower().endswith(".csv")
        ]
        if len(names) != 1:
            raise ArchiveSourceError(f"expected one CSV in {path}, found {names}")
        payload = archive.read(names[0])
    try:
        frame = pd.read_csv(io.BytesIO(payload))
    except Exception as exc:
        raise ArchiveSourceError(f"CSV parse failed {path}: {exc}") from exc
    normalized = [str(column).strip().lower() for column in frame.columns]
    if not any(
        column in {"open_time", "open time", "open_time_ms", "calc_time", "fundingtime"}
        for column in normalized
    ):
        frame = pd.read_csv(io.BytesIO(payload), header=None)
    return frame


def parse_kline_archive(path: Path) -> pd.DataFrame:
    frame = _read_zip_csv(path)
    if all(isinstance(column, int) for column in frame.columns):
        if frame.shape[1] < 11:
            raise ArchiveSourceError(f"kline width below 11 in {path}: {frame.shape}")
        frame = frame.iloc[:, : min(frame.shape[1], 12)].copy()
        frame.columns = KLINE_COLUMNS[: frame.shape[1]]
    else:
        aliases = {
            "open_time": "open_time_ms",
            "open time": "open_time_ms",
            "open_time_ms": "open_time_ms",
            "open": "open",
            "high": "high",
            "low": "low",
            "close": "close",
            "volume": "volume",
            "close_time": "close_time_ms",
            "close time": "close_time_ms",
            "close_time_ms": "close_time_ms",
            "quote_volume": "quote_volume",
            "quote asset volume": "quote_volume",
            "quote_asset_volume": "quote_volume",
            "trades": "trade_count",
            "number_of_trades": "trade_count",
            "number of trades": "trade_count",
            "count": "trade_count",
            "taker_buy_volume": "taker_base_volume",
            "taker buy volume": "taker_base_volume",
            "taker_buy_base_volume": "taker_base_volume",
            "taker buy base asset volume": "taker_base_volume",
            "taker_buy_base_asset_volume": "taker_base_volume",
            "taker_buy_quote_volume": "taker_quote_volume",
            "taker buy quote asset volume": "taker_quote_volume",
            "taker_buy_quote_asset_volume": "taker_quote_volume",
            "ignore": "ignore",
        }
        renamed: dict[Any, str] = {}
        for column in frame.columns:
            key = str(column).strip().lower()
            if key in aliases:
                renamed[column] = aliases[key]
        frame = frame.rename(columns=renamed)
    required = KLINE_COLUMNS[:11]
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise ArchiveSourceError(f"missing kline columns {missing} in {path}")
    frame = frame[required].copy()
    for column in required:
        frame[column] = pd.to_numeric(frame[column], errors="raise")
    for column in ("open_time_ms", "close_time_ms"):
        values = frame[column].astype("int64")
        # Binance spot switched to microseconds in 2025; normalize defensively.
        if len(values) and int(values.abs().median()) > 10**14:
            values = values // 1000
        frame[column] = values
    if not np.isfinite(frame[["open", "high", "low", "close"]].to_numpy()).all():
        raise ArchiveSourceError(f"non-finite OHLC in {path}")
    if (frame[["open", "high", "low", "close"]] <= 0).any().any():
        raise ArchiveSourceError(f"non-positive OHLC in {path}")
    return frame


def parse_funding_archive(path: Path) -> pd.DataFrame:
    frame = _read_zip_csv(path)
    if all(isinstance(column, int) for column in frame.columns):
        if frame.shape[1] < 2:
            raise ArchiveSourceError(f"funding width below 2 in {path}: {frame.shape}")
        frame = frame.iloc[:, :3].copy()
        names = ["funding_time_ms", "funding_rate", "mark_price"][: frame.shape[1]]
        frame.columns = names
    else:
        normalized = {str(column).strip().lower(): column for column in frame.columns}
        time_column = next(
            (
                normalized[key]
                for key in (
                    "fundingtime",
                    "funding_time",
                    "funding_time_ms",
                    "calc_time",
                    "time",
                )
                if key in normalized
            ),
            None,
        )
        rate_column = next(
            (
                normalized[key]
                for key in (
                    "fundingrate",
                    "funding_rate",
                    "last_funding_rate",
                    "rate",
                )
                if key in normalized
            ),
            None,
        )
        mark_column = next(
            (
                normalized[key]
                for key in ("markprice", "mark_price")
                if key in normalized
            ),
            None,
        )
        if time_column is None or rate_column is None:
            raise ArchiveSourceError(
                f"funding columns not recognized in {path}: {list(frame.columns)}"
            )
        selected = pd.DataFrame(
            {
                "funding_time_ms": frame[time_column],
                "funding_rate": frame[rate_column],
                "mark_price": frame[mark_column] if mark_column is not None else np.nan,
            }
        )
        frame = selected
    frame["funding_time_ms"] = pd.to_numeric(frame["funding_time_ms"], errors="raise").astype("int64")
    if len(frame) and int(frame.funding_time_ms.abs().median()) > 10**14:
        frame["funding_time_ms"] //= 1000
    frame["funding_rate"] = pd.to_numeric(frame["funding_rate"], errors="raise")
    frame["mark_price"] = pd.to_numeric(frame["mark_price"], errors="coerce")
    if not np.isfinite(frame.funding_rate.to_numpy()).all():
        raise ArchiveSourceError(f"non-finite funding in {path}")
    return frame[["funding_time_ms", "funding_rate", "mark_price"]]


def _month_key(symbol: str, interval: str, month: datetime) -> str:
    stamp = f"{month:%Y-%m}"
    return (
        f"data/futures/um/monthly/klines/{symbol}/{interval}/"
        f"{symbol}-{interval}-{stamp}.zip"
    )


def fetch_curve_frames(
    session: requests.Session,
    cache: Path,
    pair: str,
    interval: str,
    start_ms: int,
    end_ms: int,
) -> tuple[dict[str, pd.DataFrame], list[dict[str, Any]]]:
    months = month_starts(start_ms, end_ms)
    expiries = quarter_expiries(start_ms, end_ms)
    manifest: list[dict[str, Any]] = []

    perpetual_parts: list[pd.DataFrame] = []
    for month in months:
        key = _month_key(pair, interval, month)
        path, item = download_verified_archive(session, cache, key)
        perpetual_parts.append(parse_kline_archive(path))
        manifest.append({**asdict(item), "role": "PERPETUAL"})
    perpetual = pd.concat(perpetual_parts, ignore_index=True)
    perpetual = perpetual[
        (perpetual.open_time_ms >= start_ms) & (perpetual.open_time_ms < end_ms)
    ]
    perpetual = perpetual.drop_duplicates("open_time_ms", keep=False).sort_values("open_time_ms")
    if perpetual.empty:
        raise ArchiveSourceError(f"empty perpetual archive frame for {pair}")

    dated_parts: list[pd.DataFrame] = []
    attempted = 0
    found = 0
    for month in months:
        for symbol, expiry_ms in contract_symbols_for_month(pair, month, expiries):
            attempted += 1
            key = _month_key(symbol, interval, month)
            try:
                path, item = download_verified_archive(
                    session, cache, key, allow_missing=True
                )
            except ArchiveMissing:
                continue
            part = parse_kline_archive(path)
            part["expiry_ms"] = expiry_ms
            part["contract_symbol"] = symbol
            dated_parts.append(part)
            found += 1
            manifest.append(
                {
                    **asdict(item),
                    "role": "DATED_QUARTERLY",
                    "contract_symbol": symbol,
                    "expiry_ms": expiry_ms,
                }
            )
    if not dated_parts:
        raise ArchiveSourceError(
            f"no dated quarterly archives found for {pair}; attempted={attempted}"
        )
    dated = pd.concat(dated_parts, ignore_index=True)
    dated = dated[
        (dated.open_time_ms >= start_ms)
        & (dated.open_time_ms < end_ms)
        & (dated.expiry_ms > dated.open_time_ms)
    ]
    dated = dated.drop_duplicates(["open_time_ms", "contract_symbol"], keep=False)
    dated = dated.sort_values(["open_time_ms", "expiry_ms", "contract_symbol"])
    dated["curve_rank"] = dated.groupby("open_time_ms", sort=False).cumcount()

    curve_frames: dict[str, pd.DataFrame] = {"PERPETUAL": perpetual.reset_index(drop=True)}
    for label, rank in (("CURRENT_QUARTER", 0), ("NEXT_QUARTER", 1)):
        frame = dated[dated.curve_rank == rank].copy()
        frame = frame.drop(columns=["expiry_ms", "contract_symbol", "curve_rank"])
        frame = frame.drop_duplicates("open_time_ms", keep=False).sort_values("open_time_ms")
        if frame.empty:
            raise ArchiveSourceError(f"empty {label} stitched frame for {pair}")
        curve_frames[label] = frame.reset_index(drop=True)
    overlap = set(curve_frames["CURRENT_QUARTER"].open_time_ms).intersection(
        set(curve_frames["NEXT_QUARTER"].open_time_ms)
    )
    if not overlap:
        raise ArchiveSourceError(f"no current/next dated overlap for {pair}")
    manifest.append(
        {
            "source": "Binance public archive deterministic dated-contract stitch",
            "pair": pair,
            "interval": interval,
            "start_ms": start_ms,
            "end_ms": end_ms,
            "attempted_dated_archives": attempted,
            "found_dated_archives": found,
            "perpetual_rows": int(len(curve_frames["PERPETUAL"])),
            "current_quarter_rows": int(len(curve_frames["CURRENT_QUARTER"])),
            "next_quarter_rows": int(len(curve_frames["NEXT_QUARTER"])),
            "transport_sha256": _file_sha256(Path(__file__)),
        }
    )
    return curve_frames, manifest


def fetch_funding(
    session: requests.Session,
    cache: Path,
    symbol: str,
    start_ms: int,
    end_ms: int,
) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    parts: list[pd.DataFrame] = []
    manifest: list[dict[str, Any]] = []
    for month in month_starts(start_ms, end_ms):
        stamp = f"{month:%Y-%m}"
        key = (
            f"data/futures/um/monthly/fundingRate/{symbol}/"
            f"{symbol}-fundingRate-{stamp}.zip"
        )
        path, item = download_verified_archive(session, cache, key)
        parts.append(parse_funding_archive(path))
        manifest.append({**asdict(item), "role": "PERPETUAL_FUNDING"})
    frame = pd.concat(parts, ignore_index=True)
    frame = frame[
        (frame.funding_time_ms >= start_ms) & (frame.funding_time_ms < end_ms)
    ]
    frame = frame.drop_duplicates("funding_time_ms", keep=False).sort_values("funding_time_ms")
    return frame.reset_index(drop=True), manifest
