from __future__ import annotations

import io
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

import archive_source

UTC = timezone.utc


def test_contract_symbols_cover_roll_month() -> None:
    start_ms = int(datetime(2022, 1, 1, tzinfo=UTC).timestamp() * 1000)
    end_ms = int(datetime(2024, 1, 1, tzinfo=UTC).timestamp() * 1000)
    expiries = archive_source.quarter_expiries(start_ms, end_ms)
    january = archive_source.contract_symbols_for_month(
        "BTCUSDT", datetime(2023, 1, 1, tzinfo=UTC), expiries
    )
    assert [symbol for symbol, _ in january] == ["BTCUSDT_230331", "BTCUSDT_230630"]
    march = archive_source.contract_symbols_for_month(
        "BTCUSDT", datetime(2023, 3, 1, tzinfo=UTC), expiries
    )
    assert [symbol for symbol, _ in march] == [
        "BTCUSDT_230331",
        "BTCUSDT_230630",
        "BTCUSDT_230929",
    ]


def test_parse_headered_kline_zip(tmp_path: Path) -> None:
    csv = (
        "open_time,open,high,low,close,volume,close_time,quote_volume,trades,"
        "taker_buy_base_volume,taker_buy_quote_volume,ignore\n"
        "1672531200000,100,102,99,101,10,1672532099999,1005,7,6,603,0\n"
    ).encode()
    path = tmp_path / "fixture.zip"
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("fixture.csv", csv)
    frame = archive_source.parse_kline_archive(path)
    assert list(frame.columns) == archive_source.KLINE_COLUMNS[:11]
    assert int(frame.open_time_ms.iloc[0]) == 1672531200000
    assert float(frame.taker_quote_volume.iloc[0]) == 603.0


def test_parse_funding_aliases(tmp_path: Path) -> None:
    csv = b"calc_time,last_funding_rate\n1672531200000,0.0001\n"
    path = tmp_path / "funding.zip"
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("funding.csv", csv)
    frame = archive_source.parse_funding_archive(path)
    assert int(frame.funding_time_ms.iloc[0]) == 1672531200000
    assert float(frame.funding_rate.iloc[0]) == 0.0001
