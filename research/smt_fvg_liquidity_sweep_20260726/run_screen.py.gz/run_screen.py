from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import math
import os
import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
import requests

CLAIM_ID = "CLM-20260726-1539-SMT-FVG-SWEEP-001"
RESULT_ID = "RES-20260726-SMT-FVG-SWEEP-FATAL-001"
SYMBOLS = ("BTCUSDT", "ETHUSDT")
FIT_DATES = ("2023-01-15", "2023-03-19", "2023-05-21")
DEVELOPMENT_DATES = ("2023-07-16", "2023-09-17", "2023-11-19")
ALL_DATES = FIT_DATES + DEVELOPMENT_DATES
BASE_URL = "https://public.bybit.com/trading"

BAR_SECONDS = 1
SWING_BAR_SECONDS = 5
PIVOT_SPANS = (2, 4)
POOL_MODES = ("single", "equal")
EQUAL_TOLERANCE_BPS = 6.0
CONFIRM_SECONDS = (3, 10)
ENTRY_LATENCY_SECONDS = 0.1
STOP_BUFFER_BPS = 1.0
COSTS_BPS = (12.0, 18.0, 24.0)

REVERSAL_GRID = {
    "overshoot_min_bps": (0.0, 3.0),
    "pair_margin_min_bps": (0.0, 3.0),
    "reclaim_min_bps": (0.5, 2.0),
    "reversal_flow_min": (0.0, 0.2),
    "displacement_ratio_min": (1.0, 2.0),
    "fvg_min_bps": (0.0, 1.0),
    "entry_mode": ("market", "fvg"),
    "target_r": (1.5, 2.5),
}
CATCHUP_GRID = {
    "overshoot_min_bps": (0.0, 3.0),
    "pair_margin_min_bps": (0.0, 3.0),
    "hold_min_bps": (0.5, 2.0),
    "sweep_flow_min": (0.2, 0.4),
    "pair_flow_min": (0.0, 0.2),
    "pair_target_distance_min_bps": (6.0, 12.0),
    "target_r": (1.5, 2.5),
}

EXPECTED_REVERSAL_CANDIDATES = (
    len(PIVOT_SPANS)
    * len(POOL_MODES)
    * len(CONFIRM_SECONDS)
    * math.prod(len(values) for values in REVERSAL_GRID.values())
)
EXPECTED_CATCHUP_CANDIDATES = (
    len(PIVOT_SPANS)
    * len(POOL_MODES)
    * len(CONFIRM_SECONDS)
    * math.prod(len(values) for values in CATCHUP_GRID.values())
)
EXPECTED_CANDIDATES = EXPECTED_REVERSAL_CANDIDATES + EXPECTED_CATCHUP_CANDIDATES


class ContractError(RuntimeError):
    pass


def finite(value: Any) -> Any:
    if isinstance(value, (np.integer, int)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        value = float(value)
        return value if math.isfinite(value) else None
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    return value


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def stable_id(payload: dict[str, Any], length: int = 20) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()[:length]


def stage_for_date(date: str) -> str:
    if date in FIT_DATES:
        return "fit"
    if date in DEVELOPMENT_DATES:
        return "development"
    raise ContractError(f"unregistered date: {date}")


def download_archive(symbol: str, date: str, cache: Path) -> tuple[Path, dict[str, Any]]:
    cache.mkdir(parents=True, exist_ok=True)
    filename = f"{symbol}{date}.csv.gz"
    path = cache / symbol / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    url = f"{BASE_URL}/{symbol}/{filename}"
    if not path.is_file() or path.stat().st_size == 0:
        temporary = path.with_suffix(path.suffix + ".part")
        temporary.unlink(missing_ok=True)
        last_error: Exception | None = None
        for attempt in range(1, 5):
            try:
                with requests.get(
                    url,
                    stream=True,
                    timeout=(20, 240),
                    headers={"Accept-Encoding": "identity", "User-Agent": "SMC-ICT-causal-research/1.0"},
                ) as response:
                    response.raise_for_status()
                    response.raw.decode_content = False
                    with temporary.open("wb") as handle:
                        shutil.copyfileobj(response.raw, handle, length=1 << 20)
                if temporary.read_bytes()[:2] != b"\x1f\x8b":
                    raise ContractError(f"transport did not preserve gzip bytes: {url}")
                os.replace(temporary, path)
                break
            except Exception as exc:
                last_error = exc
                temporary.unlink(missing_ok=True)
                if attempt == 4:
                    raise ContractError(f"download failed for {url}: {exc}") from exc
                time.sleep(attempt * 2)
        if not path.exists() and last_error is not None:
            raise ContractError(str(last_error))

    if path.read_bytes()[:2] != b"\x1f\x8b":
        raise ContractError(f"cached file is not gzip: {path}")
    digest = sha256_file(path)
    try:
        with gzip.open(path, "rt", newline="") as handle:
            reader = csv.reader(handle)
            header = next(reader)
            rows = sum(1 for _ in reader)
    except Exception as exc:
        raise ContractError(f"gzip/CSV integrity failed for {path}: {exc}") from exc
    required = {"timestamp", "symbol", "side", "size", "price"}
    if not required.issubset(set(header)):
        raise ContractError(f"missing required fields in {path}: {header}")
    if rows <= 0:
        raise ContractError(f"empty archive: {path}")
    return path, {
        "symbol": symbol,
        "date": date,
        "url": url,
        "sha256": digest,
        "compressed_bytes": path.stat().st_size,
        "rows": rows,
        "header": header,
    }


def load_trades(path: Path, expected_symbol: str) -> pd.DataFrame:
    frame = pd.read_csv(
        path,
        compression="gzip",
        usecols=["timestamp", "symbol", "side", "size", "price"],
        dtype={
            "timestamp": "float64",
            "symbol": "string",
            "side": "string",
            "size": "float64",
            "price": "float64",
        },
    )
    if frame.empty:
        raise ContractError(f"no trades in {path}")
    if frame[["timestamp", "size", "price"]].isna().any().any():
        raise ContractError(f"non-finite core field in {path}")
    if not (frame["symbol"] == expected_symbol).all():
        raise ContractError(f"unexpected symbol in {path}")
    if not frame["side"].isin(["Buy", "Sell"]).all():
        raise ContractError(f"unexpected side in {path}")
    if (frame["size"] <= 0).any() or (frame["price"] <= 0).any():
        raise ContractError(f"non-positive trade field in {path}")
    timestamps = frame["timestamp"].to_numpy(dtype=np.float64)
    if np.any(np.diff(timestamps) < 0):
        raise ContractError(f"timestamps not nondecreasing in {path}")
    return frame


def build_bars(trades: pd.DataFrame, seconds: int = BAR_SECONDS) -> pd.DataFrame:
    ts = trades["timestamp"].to_numpy(dtype=np.float64)
    price = trades["price"].to_numpy(dtype=np.float64)
    size = trades["size"].to_numpy(dtype=np.float64)
    side = np.where(trades["side"].to_numpy() == "Buy", 1.0, -1.0)
    bucket = (np.floor(ts / seconds).astype(np.int64) * seconds).astype(np.int64)
    raw = pd.DataFrame(
        {
            "sec": bucket,
            "price": price,
            "notional": price * size,
            "signed_notional": side * price * size,
        }
    )
    grouped = raw.groupby("sec", sort=True, observed=True)
    bars = grouped.agg(
        open=("price", "first"),
        high=("price", "max"),
        low=("price", "min"),
        close=("price", "last"),
        total_notional=("notional", "sum"),
        signed_notional=("signed_notional", "sum"),
        trades=("price", "size"),
    ).reset_index()
    bars["available_time"] = bars["sec"].astype(float) + float(seconds)
    if bars.empty or np.any(np.diff(bars["sec"].to_numpy()) <= 0):
        raise ContractError("bar construction failed")
    return bars


def build_swing_bars(one_second_bars: pd.DataFrame) -> pd.DataFrame:
    raw = one_second_bars.copy()
    raw["bucket"] = (raw["sec"].to_numpy(dtype=np.int64) // SWING_BAR_SECONDS) * SWING_BAR_SECONDS
    grouped = raw.groupby("bucket", sort=True, observed=True)
    swing = grouped.agg(
        open=("open", "first"),
        high=("high", "max"),
        low=("low", "min"),
        close=("close", "last"),
        total_notional=("total_notional", "sum"),
        signed_notional=("signed_notional", "sum"),
        bars=("sec", "size"),
    ).reset_index().rename(columns={"bucket": "sec"})
    swing["available_time"] = swing["sec"].astype(float) + SWING_BAR_SECONDS
    return swing


def detect_confirmed_pivots(swing_bars: pd.DataFrame, span: int) -> list[dict[str, Any]]:
    highs = swing_bars["high"].to_numpy(dtype=float)
    lows = swing_bars["low"].to_numpy(dtype=float)
    secs = swing_bars["sec"].to_numpy(dtype=np.int64)
    pivots: list[dict[str, Any]] = []
    for i in range(span, len(swing_bars) - span):
        left_high = np.max(highs[i - span : i])
        right_high = np.max(highs[i + 1 : i + span + 1])
        left_low = np.min(lows[i - span : i])
        right_low = np.min(lows[i + 1 : i + span + 1])
        confirm_time = float(secs[i + span] + SWING_BAR_SECONDS)
        if highs[i] > left_high and highs[i] >= right_high:
            payload = {
                "kind": "high",
                "pivot_sec": int(secs[i]),
                "confirm_time": confirm_time,
                "level": float(highs[i]),
                "span": span,
            }
            payload["pivot_id"] = stable_id(payload)
            pivots.append(payload)
        if lows[i] < left_low and lows[i] <= right_low:
            payload = {
                "kind": "low",
                "pivot_sec": int(secs[i]),
                "confirm_time": confirm_time,
                "level": float(lows[i]),
                "span": span,
            }
            payload["pivot_id"] = stable_id(payload)
            pivots.append(payload)
    pivots.sort(key=lambda row: (row["confirm_time"], row["kind"], row["pivot_sec"]))
    return pivots


def pool_events_from_pivots(
    pivots: list[dict[str, Any]],
    span: int,
    mode: str,
    equal_tolerance_bps: float = EQUAL_TOLERANCE_BPS,
) -> dict[str, list[dict[str, Any]]]:
    if mode not in POOL_MODES:
        raise ContractError(f"bad pool mode: {mode}")
    out: dict[str, list[dict[str, Any]]] = {"high": [], "low": []}
    previous: dict[str, dict[str, Any] | None] = {"high": None, "low": None}
    for pivot in pivots:
        kind = str(pivot["kind"])
        if mode == "single":
            payload = {
                "kind": kind,
                "confirm_time": float(pivot["confirm_time"]),
                "level": float(pivot["level"]),
                "span": span,
                "mode": mode,
                "source_pivots": [pivot["pivot_id"]],
            }
            payload["pool_id"] = stable_id(payload)
            out[kind].append(payload)
        else:
            prior = previous[kind]
            if prior is not None:
                distance_bps = abs(float(pivot["level"]) / float(prior["level"]) - 1.0) * 1e4
                if distance_bps <= equal_tolerance_bps:
                    if kind == "high":
                        level = max(float(prior["level"]), float(pivot["level"]))
                    else:
                        level = min(float(prior["level"]), float(pivot["level"]))
                    payload = {
                        "kind": kind,
                        "confirm_time": float(pivot["confirm_time"]),
                        "level": level,
                        "span": span,
                        "mode": mode,
                        "equal_tolerance_bps": equal_tolerance_bps,
                        "source_pivots": [prior["pivot_id"], pivot["pivot_id"]],
                    }
                    payload["pool_id"] = stable_id(payload)
                    out[kind].append(payload)
            previous[kind] = pivot
    return out


def align_pool_state(bars: pd.DataFrame, pool_events: dict[str, list[dict[str, Any]]]) -> pd.DataFrame:
    secs = bars["sec"].to_numpy(dtype=np.int64)
    state = pd.DataFrame({"sec": secs})
    for kind in ("high", "low"):
        levels = np.full(len(bars), np.nan, dtype=float)
        ids = np.full(len(bars), "", dtype=object)
        events = sorted(pool_events[kind], key=lambda row: row["confirm_time"])
        cursor = 0
        current_level = math.nan
        current_id = ""
        for i, sec in enumerate(secs):
            available = float(sec + BAR_SECONDS)
            while cursor < len(events) and float(events[cursor]["confirm_time"]) <= available + 1e-12:
                current_level = float(events[cursor]["level"])
                current_id = str(events[cursor]["pool_id"])
                cursor += 1
            levels[i] = current_level
            ids[i] = current_id
        state[f"{kind}_level"] = levels
        state[f"{kind}_id"] = ids
    return state


def first_pool_crossings(
    bars: pd.DataFrame, state: pd.DataFrame
) -> dict[str, dict[str, dict[str, Any]]]:
    """First post-confirmation inside-to-outside crossing for each pool.

    A pivot level is not tradable merely because price is already beyond it when
    the right-side confirmation completes. Requiring the same pool on the prior
    bar and a prior inside observation prevents retroactive "sweeps."
    """
    result: dict[str, dict[str, dict[str, Any]]] = {"high": {}, "low": {}}
    secs = bars["sec"].to_numpy(dtype=np.int64)
    highs = bars["high"].to_numpy(dtype=float)
    lows = bars["low"].to_numpy(dtype=float)
    high_ids = state["high_id"].astype(str).to_numpy()
    low_ids = state["low_id"].astype(str).to_numpy()
    high_levels = state["high_level"].to_numpy(dtype=float)
    low_levels = state["low_level"].to_numpy(dtype=float)
    for i in range(1, len(bars)):
        high_id = str(high_ids[i])
        high_level = float(high_levels[i])
        if (
            high_id
            and high_id == str(high_ids[i - 1])
            and high_id not in result["high"]
            and math.isfinite(high_level)
            and float(highs[i - 1]) < high_level
            and float(highs[i]) >= high_level
        ):
            result["high"][high_id] = {
                "sec": int(secs[i]),
                "index": i,
                "level": high_level,
                "extreme": float(highs[i]),
            }
        low_id = str(low_ids[i])
        low_level = float(low_levels[i])
        if (
            low_id
            and low_id == str(low_ids[i - 1])
            and low_id not in result["low"]
            and math.isfinite(low_level)
            and float(lows[i - 1]) > low_level
            and float(lows[i]) <= low_level
        ):
            result["low"][low_id] = {
                "sec": int(secs[i]),
                "index": i,
                "level": low_level,
                "extreme": float(lows[i]),
            }
    return result


def sec_index_map(bars: pd.DataFrame) -> dict[int, int]:
    return {int(sec): i for i, sec in enumerate(bars["sec"].to_numpy(dtype=np.int64))}


def contiguous_window(bars: pd.DataFrame, start_sec: int, end_time: int) -> pd.DataFrame:
    # Includes bars with start_sec <= sec and sec + 1 <= end_time.
    window = bars[(bars["sec"] >= start_sec) & (bars["sec"] < end_time)]
    return window


def largest_fvg(window: pd.DataFrame, direction: int, reference_price: float) -> dict[str, Any]:
    if len(window) < 3:
        return {"gap_bps": 0.0, "midpoint": math.nan, "formation_time": math.nan}
    secs = window["sec"].to_numpy(dtype=np.int64)
    highs = window["high"].to_numpy(dtype=float)
    lows = window["low"].to_numpy(dtype=float)
    best = {"gap_bps": 0.0, "midpoint": math.nan, "formation_time": math.nan}
    for i in range(len(window) - 2):
        if secs[i + 1] != secs[i] + 1 or secs[i + 2] != secs[i] + 2:
            continue
        if direction == 1:  # high sweep, bearish FVG
            if highs[i + 2] < lows[i]:
                gap = (lows[i] / highs[i + 2] - 1.0) * 1e4
                midpoint = (lows[i] + highs[i + 2]) / 2.0
            else:
                continue
        else:  # low sweep, bullish FVG
            if lows[i + 2] > highs[i]:
                gap = (lows[i + 2] / highs[i] - 1.0) * 1e4
                midpoint = (lows[i + 2] + highs[i]) / 2.0
            else:
                continue
        if gap > best["gap_bps"]:
            best = {
                "gap_bps": float(gap),
                "midpoint": float(midpoint),
                "formation_time": float(secs[i + 2] + 1),
            }
    return best


def generate_events_for_date(
    date: str,
    symbol_data: dict[str, dict[str, Any]],
    span: int,
    mode: str,
) -> list[dict[str, Any]]:
    states: dict[str, pd.DataFrame] = {}
    crossings: dict[str, dict[str, dict[str, dict[str, Any]]]] = {}
    sec_maps: dict[str, dict[int, int]] = {}
    for symbol in SYMBOLS:
        bars = symbol_data[symbol]["bars"]
        swing = symbol_data[symbol]["swing"]
        pivots = detect_confirmed_pivots(swing, span)
        pools = pool_events_from_pivots(pivots, span, mode)
        state = align_pool_state(bars, pools)
        states[symbol] = state
        crossings[symbol] = first_pool_crossings(bars, state)
        sec_maps[symbol] = sec_index_map(bars)

    events: list[dict[str, Any]] = []
    for sweeper in SYMBOLS:
        pair = SYMBOLS[1] if sweeper == SYMBOLS[0] else SYMBOLS[0]
        bars = symbol_data[sweeper]["bars"]
        pair_bars = symbol_data[pair]["bars"]
        state = states[sweeper]
        pair_state = states[pair]
        pair_map = sec_maps[pair]
        for kind, direction in (("high", 1), ("low", -1)):
            for pool_id, crossing in crossings[sweeper][kind].items():
                sweep_sec = int(crossing["sec"])
                if sweep_sec not in pair_map:
                    continue
                i = int(crossing["index"])
                j = pair_map[sweep_sec]
                pair_pool_id = str(pair_state.iloc[j][f"{kind}_id"])
                pair_pool_level = float(pair_state.iloc[j][f"{kind}_level"])
                if not pair_pool_id or not math.isfinite(pair_pool_level):
                    continue
                pair_cross = crossings[pair][kind].get(pair_pool_id)
                if pair_cross is not None and int(pair_cross["sec"]) <= sweep_sec:
                    continue
                pool_level = float(crossing["level"])
                if direction == 1:
                    overshoot_bps = (float(bars.iloc[i]["high"]) / pool_level - 1.0) * 1e4
                    pair_margin_bps = max(
                        0.0, (pair_pool_level - float(pair_bars.iloc[j]["high"])) / pair_pool_level * 1e4
                    )
                    opposite_level = float(state.iloc[i]["low_level"])
                else:
                    overshoot_bps = (pool_level / float(bars.iloc[i]["low"]) - 1.0) * 1e4
                    pair_margin_bps = max(
                        0.0, (float(pair_bars.iloc[j]["low"]) - pair_pool_level) / pair_pool_level * 1e4
                    )
                    opposite_level = float(state.iloc[i]["high_level"])
                for confirm_seconds in CONFIRM_SECONDS:
                    decision_time = float(sweep_sec + confirm_seconds)
                    window = contiguous_window(bars, sweep_sec, int(decision_time))
                    pair_window = contiguous_window(pair_bars, sweep_sec, int(decision_time))
                    if len(window) < max(2, int(math.ceil(confirm_seconds * 0.67))):
                        continue
                    if len(pair_window) < max(2, int(math.ceil(confirm_seconds * 0.67))):
                        continue
                    extreme = float(window["high"].max() if direction == 1 else window["low"].min())
                    final_close = float(window.iloc[-1]["close"])
                    total = float(window["total_notional"].sum())
                    signed = float(window["signed_notional"].sum())
                    pair_total = float(pair_window["total_notional"].sum())
                    pair_signed = float(pair_window["signed_notional"].sum())
                    if total <= 0 or pair_total <= 0:
                        continue
                    hold_bps = direction * (final_close / pool_level - 1.0) * 1e4
                    reclaim_bps = -hold_bps
                    sweep_flow = direction * signed / total
                    reversal_flow = -sweep_flow
                    if direction == 1:
                        reversal_move_bps = max(0.0, (extreme - final_close) / pool_level * 1e4)
                    else:
                        reversal_move_bps = max(0.0, (final_close - extreme) / pool_level * 1e4)
                    prior = bars[(bars["sec"] < sweep_sec) & (bars["sec"] >= sweep_sec - 60)]
                    if len(prior) < 10:
                        continue
                    prior_range_bps = (
                        (prior["high"].to_numpy(dtype=float) / prior["low"].to_numpy(dtype=float) - 1.0) * 1e4
                    )
                    prior_range_median = float(np.median(prior_range_bps))
                    displacement_ratio = reversal_move_bps / max(prior_range_median, 0.05)
                    fvg = largest_fvg(window, direction, pool_level)
                    pair_final = float(pair_window.iloc[-1]["close"])
                    pair_start = float(pair_window.iloc[0]["open"])
                    pair_flow = direction * pair_signed / pair_total
                    pair_move_bps = direction * (pair_final / pair_start - 1.0) * 1e4
                    pair_target_distance_bps = direction * (pair_pool_level / pair_final - 1.0) * 1e4
                    payload = {
                        "stage": stage_for_date(date),
                        "date": date,
                        "span": span,
                        "mode": mode,
                        "sweeper": sweeper,
                        "pair": pair,
                        "kind": kind,
                        "direction": direction,
                        "sweep_sec": sweep_sec,
                        "decision_time": decision_time,
                        "confirm_seconds": confirm_seconds,
                        "pool_id": pool_id,
                        "pool_level": pool_level,
                        "opposite_pool_level": opposite_level,
                        "pair_pool_id": pair_pool_id,
                        "pair_pool_level": pair_pool_level,
                        "overshoot_bps": float(overshoot_bps),
                        "pair_margin_bps": float(pair_margin_bps),
                        "sweep_extreme": extreme,
                        "final_close": final_close,
                        "hold_bps": float(hold_bps),
                        "reclaim_bps": float(reclaim_bps),
                        "sweep_flow": float(sweep_flow),
                        "reversal_flow": float(reversal_flow),
                        "reversal_move_bps": float(reversal_move_bps),
                        "prior_range_median_bps": prior_range_median,
                        "displacement_ratio": float(displacement_ratio),
                        "fvg_gap_bps": float(fvg["gap_bps"]),
                        "fvg_midpoint": float(fvg["midpoint"]) if math.isfinite(float(fvg["midpoint"])) else math.nan,
                        "fvg_formation_time": float(fvg["formation_time"])
                        if math.isfinite(float(fvg["formation_time"]))
                        else math.nan,
                        "pair_flow": float(pair_flow),
                        "pair_move_bps": float(pair_move_bps),
                        "pair_target_distance_bps": float(pair_target_distance_bps),
                    }
                    payload["event_id"] = stable_id(
                        {
                            "date": date,
                            "span": span,
                            "mode": mode,
                            "sweeper": sweeper,
                            "kind": kind,
                            "pool_id": pool_id,
                            "sweep_sec": sweep_sec,
                            "confirm_seconds": confirm_seconds,
                        }
                    )
                    events.append(payload)
    return events


def next_trade(trades: pd.DataFrame, timestamp: float) -> tuple[int, float, float] | None:
    ts = trades["timestamp"].to_numpy(dtype=float)
    index = int(np.searchsorted(ts, timestamp, side="left"))
    if index >= len(trades):
        return None
    return index, float(ts[index]), float(trades.iloc[index]["price"])


def fvg_touch_decision(
    event: dict[str, Any],
    symbol_data: dict[str, dict[str, Any]],
    stop: float,
) -> float | None:
    midpoint = float(event["fvg_midpoint"])
    formation = float(event["fvg_formation_time"])
    if not math.isfinite(midpoint) or not math.isfinite(formation):
        return None
    bars = symbol_data[str(event["sweeper"])]["bars"]
    start_sec = int(math.floor(max(float(event["decision_time"]), formation)))
    direction = int(event["direction"])
    for _, bar in bars[bars["sec"] >= start_sec].iterrows():
        if direction == 1:
            if float(bar["high"]) >= stop:
                return None
            if float(bar["high"]) >= midpoint:
                return float(bar["sec"] + 1)
        else:
            if float(bar["low"]) <= stop:
                return None
            if float(bar["low"]) <= midpoint:
                return float(bar["sec"] + 1)
    return None


def evaluate_barrier_exit(
    trades: pd.DataFrame,
    bars: pd.DataFrame,
    entry_index: int,
    entry_time: float,
    side: int,
    stop: float,
    target: float,
) -> tuple[float, float, str]:
    ts = trades["timestamp"].to_numpy(dtype=float)
    prices = trades["price"].to_numpy(dtype=float)
    next_full_sec = int(math.ceil(entry_time))
    end_partial = int(np.searchsorted(ts, next_full_sec, side="left"))
    for k in range(entry_index + 1, min(end_partial, len(trades))):
        price = float(prices[k])
        if side == 1:
            if price <= stop:
                return float(ts[k]), price, "stop_partial_second"
            if price >= target:
                return float(ts[k]), target, "target_partial_second"
        else:
            if price >= stop:
                return float(ts[k]), price, "stop_partial_second"
            if price <= target:
                return float(ts[k]), target, "target_partial_second"

    for _, bar in bars[bars["sec"] >= next_full_sec].iterrows():
        open_price = float(bar["open"])
        high = float(bar["high"])
        low = float(bar["low"])
        sec = float(bar["sec"])
        if side == 1:
            if open_price <= stop:
                return sec, open_price, "adverse_gap_stop"
            if low <= stop:
                return sec + 1.0, stop, "stop_first"
            if high >= target:
                return sec + 1.0, target, "target"
        else:
            if open_price >= stop:
                return sec, open_price, "adverse_gap_stop"
            if high >= stop:
                return sec + 1.0, stop, "stop_first"
            if low <= target:
                return sec + 1.0, target, "target"

    # Source boundary is not a favorable exit. Charge the full planned stop.
    terminal_time = float(ts[-1])
    return terminal_time, stop, "terminal_full_stop"


def build_trade_outcome(
    event: dict[str, Any],
    family: str,
    entry_mode: str,
    target_r: float,
    all_data: dict[str, dict[str, dict[str, Any]]],
) -> dict[str, Any] | None:
    date = str(event["date"])
    direction = int(event["direction"])
    if family == "reversal":
        symbol = str(event["sweeper"])
        side = -direction
        stop = float(event["sweep_extreme"]) * (1.0 + direction * STOP_BUFFER_BPS / 1e4)
        decision_time = float(event["decision_time"])
        if entry_mode == "fvg":
            decision = fvg_touch_decision(event, all_data[date], stop)
            if decision is None:
                return None
            decision_time = decision
    elif family == "catchup":
        symbol = str(event["pair"])
        side = direction
        entry_mode = "market"
        decision_time = float(event["decision_time"])
        stop = math.nan
    else:
        raise ContractError(f"bad family: {family}")

    trades = all_data[date][symbol]["trades"]
    bars = all_data[date][symbol]["bars"]
    found = next_trade(trades, decision_time + ENTRY_LATENCY_SECONDS)
    if found is None:
        return None
    entry_index, entry_time, entry_price = found

    if family == "reversal":
        risk = side * (entry_price - stop)
        if risk <= 0:
            return None
        target = entry_price + side * target_r * risk
    else:
        target = float(event["pair_pool_level"])
        target_distance = side * (target - entry_price)
        if target_distance <= 0:
            return None
        risk = target_distance / target_r
        stop = entry_price - side * risk

    risk_bps = abs(entry_price - stop) / entry_price * 1e4
    if not math.isfinite(risk_bps) or risk_bps < 0.5 or risk_bps > 250.0:
        return None
    exit_time, exit_price, exit_reason = evaluate_barrier_exit(
        trades, bars, entry_index, entry_time, side, stop, target
    )
    gross_bps = side * (exit_price / entry_price - 1.0) * 1e4
    payload = {
        "event_id": event["event_id"],
        "stage": event["stage"],
        "date": date,
        "family": family,
        "entry_mode": entry_mode,
        "symbol": symbol,
        "side": side,
        "decision_time": decision_time,
        "entry_time": entry_time,
        "entry_price": entry_price,
        "stop_price": stop,
        "target_price": target,
        "exit_time": exit_time,
        "exit_price": exit_price,
        "exit_reason": exit_reason,
        "gross_bps": gross_bps,
        "risk_bps": risk_bps,
        "gross_r": gross_bps / risk_bps,
        "target_r": target_r,
    }
    return payload


def cartesian_product(grid: dict[str, tuple[Any, ...]]) -> Iterable[dict[str, Any]]:
    keys = list(grid)
    rows: list[dict[str, Any]] = [{}]
    for key in keys:
        rows = [dict(row, **{key: value}) for row in rows for value in grid[key]]
    return rows


def candidate_grid() -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    for span in PIVOT_SPANS:
        for mode in POOL_MODES:
            for confirm_seconds in CONFIRM_SECONDS:
                for params in cartesian_product(REVERSAL_GRID):
                    spec = {
                        "family": "reversal",
                        "span": span,
                        "mode": mode,
                        "confirm_seconds": confirm_seconds,
                        **params,
                    }
                    spec["candidate_id"] = stable_id(spec)
                    candidates.append(spec)
                for params in cartesian_product(CATCHUP_GRID):
                    spec = {
                        "family": "catchup",
                        "span": span,
                        "mode": mode,
                        "confirm_seconds": confirm_seconds,
                        "entry_mode": "market",
                        "fvg_min_bps": 0.0,
                        **params,
                    }
                    spec["candidate_id"] = stable_id(spec)
                    candidates.append(spec)
    if len(candidates) != EXPECTED_CANDIDATES:
        raise ContractError(f"candidate count mismatch: {len(candidates)} != {EXPECTED_CANDIDATES}")
    if len({row["candidate_id"] for row in candidates}) != len(candidates):
        raise ContractError("candidate id collision")
    return candidates


def event_eligible(event: dict[str, Any], spec: dict[str, Any]) -> bool:
    if int(event["span"]) != int(spec["span"]):
        return False
    if str(event["mode"]) != str(spec["mode"]):
        return False
    if int(event["confirm_seconds"]) != int(spec["confirm_seconds"]):
        return False
    if float(event["overshoot_bps"]) + 1e-12 < float(spec["overshoot_min_bps"]):
        return False
    if float(event["pair_margin_bps"]) + 1e-12 < float(spec["pair_margin_min_bps"]):
        return False
    if spec["family"] == "reversal":
        return (
            float(event["reclaim_bps"]) + 1e-12 >= float(spec["reclaim_min_bps"])
            and float(event["reversal_flow"]) + 1e-12 >= float(spec["reversal_flow_min"])
            and float(event["displacement_ratio"]) + 1e-12 >= float(spec["displacement_ratio_min"])
            and float(event["fvg_gap_bps"]) + 1e-12 >= float(spec["fvg_min_bps"])
        )
    return (
        float(event["hold_bps"]) + 1e-12 >= float(spec["hold_min_bps"])
        and float(event["sweep_flow"]) + 1e-12 >= float(spec["sweep_flow_min"])
        and float(event["pair_flow"]) + 1e-12 >= float(spec["pair_flow_min"])
        and float(event["pair_target_distance_bps"]) + 1e-12
        >= float(spec["pair_target_distance_min_bps"])
    )


def one_global_slot(trades: list[dict[str, Any]]) -> list[dict[str, Any]]:
    ordered = sorted(
        trades,
        key=lambda row: (
            float(row["decision_time"]),
            float(row["entry_time"]),
            str(row["symbol"]),
            str(row["event_id"]),
        ),
    )
    selected: list[dict[str, Any]] = []
    free_time = -math.inf
    for trade in ordered:
        if float(trade["decision_time"]) < free_time - 1e-12:
            continue
        selected.append(trade)
        free_time = float(trade["exit_time"])
    return selected


def maximum_drawdown(returns: np.ndarray) -> float:
    if returns.size == 0:
        return math.nan
    equity = np.cumprod(1.0 + returns)
    peaks = np.maximum.accumulate(np.concatenate(([1.0], equity)))[:-1]
    drawdowns = 1.0 - equity / peaks
    return float(np.max(drawdowns)) if drawdowns.size else 0.0


def profit_factor(returns: np.ndarray) -> float:
    gains = float(returns[returns > 0].sum())
    losses = float(-returns[returns < 0].sum())
    if losses <= 0:
        return math.inf if gains > 0 else math.nan
    return gains / losses


def top_share(net_bps: np.ndarray, count: int = 5) -> float:
    positive = net_bps[net_bps > 0]
    total = float(positive.sum())
    if total <= 0:
        return math.nan
    return float(np.sort(positive)[-count:].sum() / total)


def removed_return(net_bps: np.ndarray, fraction: float = 0.10) -> float:
    if net_bps.size == 0:
        return math.nan
    positive_indices = np.flatnonzero(net_bps > 0)
    if positive_indices.size == 0:
        kept = net_bps
    else:
        remove_count = max(1, int(math.ceil(net_bps.size * fraction)))
        ranked = positive_indices[np.argsort(net_bps[positive_indices])[::-1]]
        remove = set(int(index) for index in ranked[:remove_count])
        kept = np.array([value for i, value in enumerate(net_bps) if i not in remove], dtype=float)
    return float(np.prod(1.0 + kept / 1e4) - 1.0)


def metrics_for_cost(trades: list[dict[str, Any]], cost_bps: float) -> dict[str, Any]:
    if not trades:
        return {
            "trades": 0,
            "mean_bps": math.nan,
            "median_bps": math.nan,
            "total_return": 0.0,
            "profit_factor": math.nan,
            "mdd": 0.0,
            "top5_positive_share": math.nan,
            "top10_removed_return": 0.0,
            "positive_date_fraction": 0.0,
            "positive_symbol_date_fraction": 0.0,
        }
    net = np.array([float(row["gross_bps"]) - cost_bps for row in trades], dtype=float)
    returns = net / 1e4
    dates = sorted({str(row["date"]) for row in trades})
    date_positive = []
    for date in dates:
        vals = [
            float(row["gross_bps"]) - cost_bps
            for row in trades
            if str(row["date"]) == date
        ]
        date_positive.append(float(np.sum(vals)) > 0)
    symbol_dates = sorted({(str(row["symbol"]), str(row["date"])) for row in trades})
    symbol_date_positive = []
    for symbol, date in symbol_dates:
        vals = [
            float(row["gross_bps"]) - cost_bps
            for row in trades
            if str(row["symbol"]) == symbol and str(row["date"]) == date
        ]
        symbol_date_positive.append(float(np.sum(vals)) > 0)
    return {
        "trades": len(trades),
        "mean_bps": float(np.mean(net)),
        "median_bps": float(np.median(net)),
        "total_return": float(np.prod(1.0 + returns) - 1.0),
        "profit_factor": profit_factor(returns),
        "mdd": maximum_drawdown(returns),
        "top5_positive_share": top_share(net, 5),
        "top10_removed_return": removed_return(net, 0.10),
        "positive_date_fraction": float(np.mean(date_positive)) if date_positive else 0.0,
        "positive_symbol_date_fraction": float(np.mean(symbol_date_positive))
        if symbol_date_positive
        else 0.0,
    }


def candidate_metrics(trades: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        str(int(cost)): metrics_for_cost(trades, cost)
        for cost in COSTS_BPS
    }


def passes_development_gate(metrics: dict[str, Any]) -> bool:
    m12 = metrics["12"]
    m18 = metrics["18"]
    m24 = metrics["24"]
    return bool(
        int(m18["trades"]) >= 12
        and float(m18["mean_bps"]) > 0
        and float(m12["median_bps"]) > 0
        and float(m24["total_return"]) > 0
        and float(m18["top10_removed_return"]) > 0
        and float(m18["positive_date_fraction"]) >= 2.0 / 3.0
        and math.isfinite(float(m18["top5_positive_share"]))
        and float(m18["top5_positive_share"]) <= 0.50
    )


def evaluate_candidates(
    candidates: list[dict[str, Any]],
    events: list[dict[str, Any]],
    all_data: dict[str, dict[str, dict[str, Any]]],
) -> tuple[pd.DataFrame, dict[str, list[dict[str, Any]]], dict[str, Any]]:
    grouped: dict[tuple[int, str, int, str], list[dict[str, Any]]] = {}
    for event in events:
        key = (
            int(event["span"]),
            str(event["mode"]),
            int(event["confirm_seconds"]),
            str(event["stage"]),
        )
        grouped.setdefault(key, []).append(event)

    outcome_cache: dict[tuple[str, str, str, float], dict[str, Any] | None] = {}
    result_rows: list[dict[str, Any]] = []
    ledgers: dict[str, list[dict[str, Any]]] = {}
    gate_count = 0
    for index, spec in enumerate(candidates, start=1):
        stage_ledgers: dict[str, list[dict[str, Any]]] = {}
        for stage in ("fit", "development"):
            source_events = grouped.get(
                (int(spec["span"]), str(spec["mode"]), int(spec["confirm_seconds"]), stage), []
            )
            outcomes: list[dict[str, Any]] = []
            for event in source_events:
                if not event_eligible(event, spec):
                    continue
                key = (
                    str(event["event_id"]),
                    str(spec["family"]),
                    str(spec.get("entry_mode", "market")),
                    float(spec["target_r"]),
                )
                if key not in outcome_cache:
                    outcome_cache[key] = build_trade_outcome(
                        event,
                        str(spec["family"]),
                        str(spec.get("entry_mode", "market")),
                        float(spec["target_r"]),
                        all_data,
                    )
                outcome = outcome_cache[key]
                if outcome is not None:
                    outcomes.append(outcome)
            stage_ledgers[stage] = one_global_slot(outcomes)

        fit_metrics = candidate_metrics(stage_ledgers["fit"])
        development_metrics = candidate_metrics(stage_ledgers["development"])
        passed = passes_development_gate(development_metrics)
        gate_count += int(passed)
        row: dict[str, Any] = {
            **spec,
            "fit_trades": int(fit_metrics["18"]["trades"]),
            "development_trades": int(development_metrics["18"]["trades"]),
            "development_gate": passed,
        }
        for stage, metrics in (("fit", fit_metrics), ("development", development_metrics)):
            for cost in ("12", "18", "24"):
                for name, value in metrics[cost].items():
                    row[f"{stage}_{cost}bp_{name}"] = finite(value)
        result_rows.append(row)
        if passed:
            ledgers[str(spec["candidate_id"])] = stage_ledgers["development"]
        if index % 256 == 0:
            print(f"CANDIDATES {index}/{len(candidates)} gate={gate_count}", flush=True)

    frame = pd.DataFrame(result_rows)
    summary = {
        "candidate_count": len(candidates),
        "development_gate_passes": gate_count,
        "outcome_cache_entries": len(outcome_cache),
    }
    return frame, ledgers, summary


def best_rows(frame: pd.DataFrame) -> dict[str, Any]:
    if frame.empty:
        return {}
    output: dict[str, Any] = {}
    for minimum in (1, 5, 10, 20, 60):
        subset = frame[pd.to_numeric(frame["development_trades"], errors="coerce") >= minimum].copy()
        if subset.empty:
            output[f"best_min_{minimum}"] = None
            continue
        subset["_score"] = pd.to_numeric(
            subset["development_18bp_total_return"], errors="coerce"
        ).fillna(-np.inf)
        row = subset.sort_values(["_score", "candidate_id"], ascending=[False, True]).iloc[0]
        output[f"best_min_{minimum}"] = {
            key: finite(row[key])
            for key in frame.columns
            if key == "candidate_id"
            or key in {
                "family",
                "span",
                "mode",
                "confirm_seconds",
                "entry_mode",
                "target_r",
                "development_trades",
                "development_gate",
                "development_12bp_mean_bps",
                "development_12bp_median_bps",
                "development_12bp_total_return",
                "development_18bp_mean_bps",
                "development_18bp_median_bps",
                "development_18bp_total_return",
                "development_18bp_profit_factor",
                "development_18bp_mdd",
                "development_18bp_top5_positive_share",
                "development_18bp_top10_removed_return",
                "development_24bp_total_return",
            }
        }
    return output


def positive_counts(frame: pd.DataFrame) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for cost in (12, 18, 24):
        total = pd.to_numeric(frame[f"development_{cost}bp_total_return"], errors="coerce")
        removed = pd.to_numeric(
            frame[f"development_{cost}bp_top10_removed_return"], errors="coerce"
        )
        out[str(cost)] = {
            "positive_total": int((total > 0).sum()),
            "positive_removed": int((removed > 0).sum()),
            "positive_total_min_10_trades": int(
                ((total > 0) & (pd.to_numeric(frame["development_trades"], errors="coerce") >= 10)).sum()
            ),
        }
    return out


def causal_self_test() -> None:
    # Pivot cannot be available before right-side bars complete.
    swing = pd.DataFrame(
        {
            "sec": np.arange(0, 45, 5),
            "open": [1, 2, 3, 2, 1, 2, 1, 1, 1],
            "high": [1, 2, 5, 2, 1, 2, 1, 1, 1],
            "low": [0.9, 1.8, 2.8, 1.8, 0.8, 1.8, 0.7, 0.8, 0.9],
            "close": [1, 2, 4, 2, 1, 2, 1, 1, 1],
            "total_notional": 1.0,
            "signed_notional": 0.0,
            "bars": 5,
            "available_time": np.arange(5, 50, 5),
        }
    )
    pivots = detect_confirmed_pivots(swing, 2)
    high = next(row for row in pivots if row["kind"] == "high" and row["pivot_sec"] == 10)
    assert high["confirm_time"] == 25.0

    # A level already beyond price at confirmation is not retroactively swept.
    bars = pd.DataFrame(
        {
            "sec": [0, 1, 2, 3],
            "open": [100, 102, 99, 101],
            "high": [101, 103, 99, 104],
            "low": [99, 101, 98, 100],
            "close": [100, 102, 99, 103],
        }
    )
    state = pd.DataFrame(
        {
            "sec": [0, 1, 2, 3],
            "high_level": [math.nan, 100.0, 100.0, 100.0],
            "high_id": ["", "h", "h", "h"],
            "low_level": [math.nan, math.nan, math.nan, math.nan],
            "low_id": ["", "", "", ""],
        }
    )
    crosses = first_pool_crossings(bars, state)
    assert crosses["high"]["h"]["sec"] == 3

    # Bearish and bullish FVG detection.
    bearish = pd.DataFrame(
        {"sec": [0, 1, 2], "high": [105, 103, 100], "low": [102, 100, 98]}
    )
    fvg = largest_fvg(bearish, 1, 100)
    assert fvg["gap_bps"] > 0 and abs(fvg["midpoint"] - 101.0) < 1e-12
    bullish = pd.DataFrame(
        {"sec": [0, 1, 2], "high": [100, 102, 105], "low": [98, 101, 103]}
    )
    fvg2 = largest_fvg(bullish, -1, 100)
    assert fvg2["gap_bps"] > 0 and abs(fvg2["midpoint"] - 101.5) < 1e-12

    # Global slot uses decision time, not post-hoc entry time.
    rows = [
        {"decision_time": 1.0, "entry_time": 2.0, "exit_time": 5.0, "symbol": "BTC", "event_id": "a"},
        {"decision_time": 3.0, "entry_time": 6.0, "exit_time": 7.0, "symbol": "ETH", "event_id": "b"},
        {"decision_time": 5.0, "entry_time": 5.1, "exit_time": 8.0, "symbol": "ETH", "event_id": "c"},
    ]
    selected = one_global_slot(rows)
    assert [row["event_id"] for row in selected] == ["a", "c"]

    # Cost replay must be monotonic.
    ledger = [
        {"gross_bps": 30.0, "date": "d1", "symbol": "BTC"},
        {"gross_bps": -5.0, "date": "d2", "symbol": "ETH"},
    ]
    totals = [metrics_for_cost(ledger, cost)["total_return"] for cost in COSTS_BPS]
    assert totals[0] >= totals[1] >= totals[2]

    grid = candidate_grid()
    assert len(grid) == EXPECTED_CANDIDATES
    assert all("candidate_id" in row for row in grid)
    print("SELF_TEST_PASS")
    print(
        json.dumps(
            {
                "candidate_count": len(grid),
                "reversal": EXPECTED_REVERSAL_CANDIDATES,
                "catchup": EXPECTED_CATCHUP_CANDIDATES,
            },
            sort_keys=True,
        )
    )


def run(cache: Path, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    source_manifest: list[dict[str, Any]] = []
    all_data: dict[str, dict[str, dict[str, Any]]] = {}
    for date in ALL_DATES:
        all_data[date] = {}
        for symbol in SYMBOLS:
            path, manifest = download_archive(symbol, date, cache)
            source_manifest.append(manifest)
            trades = load_trades(path, symbol)
            bars = build_bars(trades)
            swing = build_swing_bars(bars)
            all_data[date][symbol] = {
                "path": path,
                "trades": trades,
                "bars": bars,
                "swing": swing,
            }
            print(
                f"LOADED {date} {symbol} rows={len(trades)} bars={len(bars)} sha={manifest['sha256'][:12]}",
                flush=True,
            )

    events: list[dict[str, Any]] = []
    for date in ALL_DATES:
        for span in PIVOT_SPANS:
            for mode in POOL_MODES:
                rows = generate_events_for_date(date, all_data[date], span, mode)
                events.extend(rows)
                print(f"EVENTS {date} span={span} mode={mode} rows={len(rows)}", flush=True)
    events_frame = pd.DataFrame(events)
    if events_frame.empty:
        raise ContractError("no SMT sweep events")
    candidates = candidate_grid()
    candidate_frame, ledgers, evaluation_summary = evaluate_candidates(candidates, events, all_data)

    # Persist only compact scientific evidence; raw archives remain in cache and are hash-identified.
    events_frame.to_csv(output / "smt_events.csv.gz", index=False, compression="gzip")
    candidate_frame.to_csv(output / "candidate_results.csv", index=False)
    if ledgers:
        flattened = []
        for candidate_id, trades in ledgers.items():
            for trade in trades:
                flattened.append({"candidate_id": candidate_id, **trade})
        pd.DataFrame(flattened).to_csv(output / "survivor_ledgers.csv", index=False)
    else:
        pd.DataFrame(
            columns=[
                "candidate_id",
                "event_id",
                "stage",
                "date",
                "family",
                "entry_mode",
                "symbol",
                "side",
                "decision_time",
                "entry_time",
                "entry_price",
                "stop_price",
                "target_price",
                "exit_time",
                "exit_price",
                "exit_reason",
                "gross_bps",
                "risk_bps",
                "gross_r",
                "target_r",
            ]
        ).to_csv(output / "survivor_ledgers.csv", index=False)

    scientific_inventory = {
        "claim_id": CLAIM_ID,
        "result_id": RESULT_ID,
        "symbols": list(SYMBOLS),
        "fit_dates": list(FIT_DATES),
        "development_dates": list(DEVELOPMENT_DATES),
        "archives": source_manifest,
        "archive_count": len(source_manifest),
        "raw_trade_rows": int(sum(int(row["rows"]) for row in source_manifest)),
        "event_rows": len(events_frame),
        "fit_event_rows": int((events_frame["stage"] == "fit").sum()),
        "development_event_rows": int((events_frame["stage"] == "development").sum()),
        "candidate_count": len(candidate_frame),
        "2024_opened": False,
        "2025_opened": False,
        "2026_opened": False,
        "orders_submitted": False,
        "paper_or_live_started": False,
    }
    (output / "source_manifest.json").write_text(
        json.dumps(scientific_inventory, indent=2, sort_keys=True)
    )
    result = {
        "schema_version": 1,
        "result_id": RESULT_ID,
        "claim_id": CLAIM_ID,
        "status": "TESTED_BELOW_GATE"
        if int(evaluation_summary["development_gate_passes"]) == 0
        else "CANDIDATE_FATAL_SCREEN_SURVIVOR",
        "qualification": "FATAL_ALPHA_SCREEN_ONLY_NOT_RANK_ELIGIBLE",
        "candidate_count": len(candidate_frame),
        "development_gate_passes": int(evaluation_summary["development_gate_passes"]),
        "event_rows": len(events_frame),
        "fit_event_rows": int((events_frame["stage"] == "fit").sum()),
        "development_event_rows": int((events_frame["stage"] == "development").sum()),
        "positive_counts": positive_counts(candidate_frame),
        "best_rows": best_rows(candidate_frame),
        "maximum_development_trades": int(
            pd.to_numeric(candidate_frame["development_trades"], errors="coerce").max()
        ),
        "2024_opened": False,
        "2025_opened": False,
        "2026_opened": False,
        "orders_submitted": False,
        "paper_or_live_started": False,
        "interpretation": (
            "A survivor only justifies broader pre-2024 reconstruction and exact Bybit BBO/depth execution. "
            "This sparse trade-print screen cannot enter the cumulative strategy ranking."
        ),
    }
    (output / "result_summary.json").write_text(json.dumps(result, indent=2, sort_keys=True))
    print("RESULT_SUMMARY")
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("self-test")
    run_parser = sub.add_parser("run")
    run_parser.add_argument("--cache", type=Path, required=True)
    run_parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.command == "self-test":
        causal_self_test()
        return
    run(args.cache, args.output)


if __name__ == "__main__":
    main()
