from __future__ import annotations
import json, struct, sys
from pathlib import Path
from thrift.transport import TTransport
from thrift.protocol import TCompactProtocol
from thrift.Thrift import TType


def read_string(p):
    x=p.readString()
    return x.decode() if isinstance(x,(bytes,bytearray)) else x

def parse_schema_element(p):
    d={}; p.readStructBegin()
    while True:
        _, t, fid=p.readFieldBegin()
        if t==TType.STOP: break
        if fid==1: d['type']=p.readI32()
        elif fid==2: d['type_length']=p.readI32()
        elif fid==3: d['repetition_type']=p.readI32()
        elif fid==4: d['name']=read_string(p)
        elif fid==5: d['num_children']=p.readI32()
        elif fid==6: d['converted_type']=p.readI32()
        elif fid==7: d['scale']=p.readI32()
        elif fid==8: d['precision']=p.readI32()
        elif fid==9: d['field_id']=p.readI32()
        else: p.skip(t)
        p.readFieldEnd()
    p.readStructEnd(); return d

def parse_statistics(p):
    d={}; p.readStructBegin()
    while True:
        _,t,fid=p.readFieldBegin()
        if t==TType.STOP: break
        if fid in (1,2,5,6):
            d[{1:'max',2:'min',5:'max_value',6:'min_value'}[fid]]=p.readBinary().hex()
        elif fid in (3,4,7,8):
            d[{3:'null_count',4:'distinct_count',7:'is_max_value_exact',8:'is_min_value_exact'}[fid]]=(p.readBool() if t==TType.BOOL else p.readI64())
        else:p.skip(t)
        p.readFieldEnd()
    p.readStructEnd();return d

def parse_colmeta(p):
    d={};p.readStructBegin()
    while True:
        _,t,fid=p.readFieldBegin()
        if t==TType.STOP:break
        if fid==1:d['type']=p.readI32()
        elif fid==2:
            et,n=p.readListBegin();d['encodings']=[p.readI32() for _ in range(n)];p.readListEnd()
        elif fid==3:
            et,n=p.readListBegin();d['path_in_schema']=[read_string(p) for _ in range(n)];p.readListEnd()
        elif fid==4:d['codec']=p.readI32()
        elif fid==5:d['num_values']=p.readI64()
        elif fid==6:d['total_uncompressed_size']=p.readI64()
        elif fid==7:d['total_compressed_size']=p.readI64()
        elif fid==8:
            kt,vt,n=p.readMapBegin(); kv={}
            for _ in range(n):kv[read_string(p)]=read_string(p)
            p.readMapEnd();d['key_value_metadata']=kv
        elif fid==9:d['data_page_offset']=p.readI64()
        elif fid==10:d['index_page_offset']=p.readI64()
        elif fid==11:d['dictionary_page_offset']=p.readI64()
        elif fid==12:d['statistics']=parse_statistics(p)
        elif fid==13:d['encoding_stats']=p.skip(t)
        elif fid==14:d['bloom_filter_offset']=p.readI64()
        else:p.skip(t)
        p.readFieldEnd()
    p.readStructEnd();return d

def parse_column_chunk(p):
    d={};p.readStructBegin()
    while True:
        _,t,fid=p.readFieldBegin()
        if t==TType.STOP:break
        if fid==1:d['file_path']=read_string(p)
        elif fid==2:d['file_offset']=p.readI64()
        elif fid==3:d['meta_data']=parse_colmeta(p)
        elif fid in (4,5,6,7):
            d[{4:'offset_index_offset',5:'offset_index_length',6:'column_index_offset',7:'column_index_length'}[fid]]=p.readI64() if t==TType.I64 else p.readI32()
        else:p.skip(t)
        p.readFieldEnd()
    p.readStructEnd();return d

def parse_row_group(p):
    d={};p.readStructBegin()
    while True:
        _,t,fid=p.readFieldBegin()
        if t==TType.STOP:break
        if fid==1:
            et,n=p.readListBegin();d['columns']=[parse_column_chunk(p) for _ in range(n)];p.readListEnd()
        elif fid==2:d['total_byte_size']=p.readI64()
        elif fid==3:d['num_rows']=p.readI64()
        elif fid==5:d['file_offset']=p.readI64()
        elif fid==6:d['total_compressed_size']=p.readI64()
        elif fid==7:d['ordinal']=p.readI16()
        else:p.skip(t)
        p.readFieldEnd()
    p.readStructEnd();return d

def parse_filemeta(buf):
    p=TCompactProtocol.TCompactProtocol(TTransport.TMemoryBuffer(buf));d={};p.readStructBegin()
    while True:
        _,t,fid=p.readFieldBegin()
        if t==TType.STOP:break
        if fid==1:d['version']=p.readI32()
        elif fid==2:
            et,n=p.readListBegin();d['schema']=[parse_schema_element(p) for _ in range(n)];p.readListEnd()
        elif fid==3:d['num_rows']=p.readI64()
        elif fid==4:
            et,n=p.readListBegin();d['row_groups']=[parse_row_group(p) for _ in range(n)];p.readListEnd()
        elif fid==5:
            et,n=p.readListBegin();vals=[]
            for _ in range(n):p.skip(et)
            p.readListEnd();d['key_value_metadata_count']=n
        elif fid==6:d['created_by']=read_string(p)
        else:p.skip(t)
        p.readFieldEnd()
    p.readStructEnd();return d

def main(path):
    path=Path(path);size=path.stat().st_size
    with path.open('rb') as f:
        assert f.read(4)==b'PAR1';f.seek(-8,2);mlen=struct.unpack('<I',f.read(4))[0];assert f.read(4)==b'PAR1';f.seek(size-8-mlen);buf=f.read(mlen)
    meta=parse_filemeta(buf)
    print(json.dumps(meta,indent=2))
if __name__=='__main__':main(sys.argv[1])
