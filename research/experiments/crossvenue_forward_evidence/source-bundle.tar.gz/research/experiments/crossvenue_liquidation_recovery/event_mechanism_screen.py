from __future__ import annotations
import argparse,json,math
from pathlib import Path
import numpy as np,pandas as pd

def trim(v,n): return float(np.sort(v)[:-n].mean()) if len(v)>n else math.nan

def stats(z,dates,cost):
 if z.empty:return {'n':0,'mean':math.nan,'median':math.nan,'top5pct':math.nan,'top10pct':math.nan,'top3':math.nan,'top5':math.nan,'bps_day':0.,'positive_days':0.,'single_profit_share':1.}
 v=z.gross_bps.to_numpy(float)-cost;day=pd.to_datetime(z.decision_sec,unit='s',utc=True).dt.strftime('%Y-%m-%d');daily=pd.Series(v,index=day).groupby(level=0).sum().reindex(dates,fill_value=0.);pos=np.sort(v[v>0])[::-1];ps=pos.sum()
 def pct(p):return trim(v,max(1,int(math.ceil(len(v)*p))))
 return {'n':len(v),'mean':float(v.mean()),'median':float(np.median(v)),'top5pct':pct(.05),'top10pct':pct(.1),'top3':trim(v,3),'top5':trim(v,5),'bps_day':float(v.sum()/len(dates)),'positive_days':float((daily>0).mean()),'single_profit_share':float(pos[0]/ps) if len(pos) and ps>0 else 1.}

def one_slot(g):
 if g.empty:return g
 q=g.sort_values(['decision_sec','score','event_sec'],ascending=[True,False,True]);rows=[];free=-10**30
 for t,b in q.groupby('decision_sec',sort=True):
  t=int(t)
  if t<free:continue
  r=b.iloc[0];rows.append(r);free=int(r.exit_sec)
 return pd.DataFrame(rows)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--panel',type=Path,required=True);ap.add_argument('--events',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 z=np.load(a.panel,allow_pickle=True);names=z.files;df=pd.DataFrame({k:z[k] for k in names});ev=pd.read_csv(a.events).sort_values('event_sec')
 by={str(v):g.set_index('sec').sort_index() for v,g in df.groupby('exchange')};venues=sorted(by)
 features=[]
 for e in ev.itertuples(index=False):
  for delay in (3,5,10,20):
   t=int(e.event_sec+delay);pre=int(e.event_sec-1);side=int(e.side);state={}
   for v in venues:
    b=by[v]
    if pre not in b.index or t not in b.index:continue
    p=b.loc[pre];q=b.loc[t];react=side*np.log(float(q.mid)/float(p.mid))*1e4;flow=side*float(q.flow5) if pd.notna(q.flow5) else np.nan;micro=side*float(q.micro_bps);consumed=float(q.ask_depth_ratio if side>0 else q.bid_depth_ratio);support=float(q.bid_depth_ratio if side>0 else q.ask_depth_ratio)
    state[v]={'react':react,'flow':flow,'micro':micro,'consumed':consumed,'support':support,'spread':float(q.spread_bps),'mid':float(q.mid)}
   if 'bybit' not in state or not {'binancef','okx'}.issubset(state):continue
   lag=min(('binancef','okx'),key=lambda v:state[v]['react']);leader=max(('binancef','okx'),key=lambda v:state[v]['react']);shock_react=state['bybit']['react']
   for target in ('bybit','binancef','okx','lag'):
    v=lag if target=='lag' else target;s=state[v];features.append({'event_sec':int(e.event_sec),'decision_sec':t,'delay':delay,'event_side':side,'liq_z':float(e.liq_z),'liq_usd':float(e.liq_usd),'target_type':target,'target_venue':v,'shock_react':shock_react,'target_react':s['react'],'lag_gap':shock_react-state[lag]['react'],'leader_gap':state[leader]['react']-state[lag]['react'],'flow_side':s['flow'],'micro_side':s['micro'],'consumed_ratio':s['consumed'],'support_ratio':s['support'],'spread_bps':s['spread']})
 f=pd.DataFrame(features);f.to_csv(a.out/'EVENT_FEATURES.csv',index=False)
 # Fixed, economically distinct causal gates. No parameter optimization inside a gate.
 gates={
  'UNCOND_CONT':lambda x:np.ones(len(x),bool),
  'UNCOND_REV':lambda x:np.ones(len(x),bool),
  'FLOW_CONT':lambda x:x.flow_side>=0,
  'FLOW_REV':lambda x:x.flow_side<=0,
  'DEPLETE_CONT':lambda x:(x.flow_side>=0)&(x.micro_side>=0)&(x.consumed_ratio<=1),
  'ABSORB_REV':lambda x:(x.flow_side<=0)&(x.micro_side<=0)&(x.target_react<=0)&(x.consumed_ratio>=1),
  'EXHAUST_REV':lambda x:(x.flow_side<=0)&(x.micro_side<=0)&(x.target_react>0)&(x.consumed_ratio>=1),
  'REPLENISH_REV':lambda x:(x.flow_side<=0)&(x.consumed_ratio>=1.25),
  'TRANSFER_CONT':lambda x:(x.target_type=='lag')&(x.lag_gap>=1)&(x.flow_side>=0)&(x.consumed_ratio<=1),
  'REVERSAL_TRANSFER':lambda x:(x.target_type=='lag')&(x.shock_react<=-1)&(x.target_react>x.shock_react+1)&(x.flow_side<=0),
 }
 dates=sorted(pd.to_datetime(df.sec,unit='s',utc=True).dt.strftime('%Y-%m-%d').unique());n=len(dates);c1=n//2;c2=c1+(n-c1)//2;splits={'dev':dates[:c1],'val':dates[c1:c2],'conf':dates[c2:]};bounds={k:(int(pd.Timestamp(v[0],tz='UTC').timestamp()),int((pd.Timestamp(v[-1],tz='UTC')+pd.Timedelta(days=1)).timestamp())) for k,v in splits.items()}
 panel_lookup={v:by[v] for v in venues};policies=[];trade_cache={}
 for gate,fn in gates.items():
  direction=-1 if gate.endswith('REV') or gate in ('UNCOND_REV','FLOW_REV','ABSORB_REV','EXHAUST_REV','REPLENISH_REV','REVERSAL_TRANSFER') else 1
  for delay in (3,5,10,20):
   for target in ('bybit','binancef','okx','lag'):
    if gate in ('TRANSFER_CONT','REVERSAL_TRANSFER') and target!='lag':continue
    base=f[(f.delay==delay)&(f.target_type==target)].copy();base=base[fn(base)]
    for h in (15,30,60,120,300):
     rows=[]
     for r in base.itertuples(index=False):
      side=int(r.event_side)*direction;e=int(r.decision_sec+1);x=e+h;b=panel_lookup[str(r.target_venue)]
      if e not in b.index or x not in b.index:continue
      a0=b.loc[e];a1=b.loc[x];ep=float(a0.ask if side>0 else a0.bid);xp=float(a1.bid if side>0 else a1.ask)
      if ep<=0 or xp<=0:continue
      gross=side*(xp/ep-1)*1e4;score=abs(float(r.liq_z))+abs(float(r.flow_side))+abs(float(r.lag_gap));rows.append({**r._asdict(),'trade_side':side,'entry_sec':e,'exit_sec':x,'entry_price':ep,'exit_price':xp,'gross_bps':gross,'score':score})
     zt=one_slot(pd.DataFrame(rows));pid=f'{gate}_D{delay}_{target}_H{h}';trade_cache[pid]=zt
     rec={'policy_id':pid,'gate':gate,'delay':delay,'target':target,'horizon':h,'candidates':len(rows),'trades':len(zt)}
     for cost in (8.,12.,16.):
      rec2={**rec,'cost':cost}
      for name,ds in splits.items():
       lo,hi=bounds[name];st=stats(zt[(zt.decision_sec>=lo)&(zt.decision_sec<hi)],ds,cost);rec2.update({f'{name}_{k}':v for k,v in st.items()})
      policies.append(rec2)
 grid=pd.DataFrame(policies);grid.to_csv(a.out/'GRID.csv',index=False)
 q=grid[grid.cost==12].copy();q16=grid[grid.cost==16][['policy_id','dev_mean','val_mean','dev_top5pct','val_top5pct']].rename(columns={x:'c16_'+x for x in ['dev_mean','val_mean','dev_top5pct','val_top5pct']});q=q.merge(q16,on='policy_id')
 strict=q[(q.dev_n>=20)&(q.val_n>=8)&(q.dev_mean>0)&(q.val_mean>0)&(q.dev_top5pct>0)&(q.val_top5pct>0)&(q.dev_top10pct>0)&(q.val_top10pct>0)&(q.c16_dev_mean>0)&(q.c16_val_mean>0)&(q.c16_dev_top5pct>0)&(q.c16_val_top5pct>0)&(q.dev_single_profit_share<=.2)&(q.val_single_profit_share<=.2)].copy()
 if len(strict):strict['score']=strict[['dev_mean','val_mean','dev_top5pct','val_top5pct','c16_dev_mean','c16_val_mean']].min(axis=1);strict=strict.sort_values('score',ascending=False)
 exploratory=q[(q.dev_n>=10)&(q.val_n>=5)&(q.dev_mean>0)&(q.val_mean>0)&(q.dev_top3>0)&(q.val_top3>0)&(q.c16_dev_mean>0)&(q.c16_val_mean>0)].copy()
 if len(exploratory):exploratory['score']=exploratory[['dev_mean','val_mean','dev_top3','val_top3','c16_dev_mean','c16_val_mean']].min(axis=1);exploratory=exploratory.sort_values('score',ascending=False)
 strict.to_csv(a.out/'STRICT.csv',index=False);exploratory.to_csv(a.out/'EXPLORATORY.csv',index=False)
 top=q.assign(floor=q[['dev_mean','val_mean','dev_top5pct','val_top5pct','c16_dev_mean','c16_val_mean']].min(axis=1)).sort_values('floor',ascending=False).head(50);top.to_csv(a.out/'TOP.csv',index=False)
 summary={'status':'STRICT_CANDIDATE' if len(strict) else 'CASH','event_count':int(len(ev)),'feature_rows':int(len(f)),'policies':int(grid.policy_id.nunique()),'dates':dates,'splits':splits,'strict_count':int(len(strict)),'exploratory_count':int(len(exploratory)),'top':top.head(20).replace({np.nan:None}).to_dict('records'),'causality':'fixed delay, completed-second state, next-second touch, chronological one-slot','limitations':['10 calendar days only','Bybit liquidation events only','exchange timestamp only','no local receive time or private execution']}
 (a.out/'SUMMARY.json').write_text(json.dumps(summary,indent=2,sort_keys=True,default=str)+'\n');print(json.dumps({k:summary[k] for k in ('status','event_count','feature_rows','policies','strict_count','exploratory_count')},indent=2))
if __name__=='__main__':main()
