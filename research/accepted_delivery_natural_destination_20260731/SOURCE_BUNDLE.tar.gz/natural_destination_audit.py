from __future__ import annotations

import importlib.util
import io
import json
import math
import pathlib
import os
import subprocess
import sys
import zipfile
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

REPO_ROOT = pathlib.Path(__file__).resolve().parents[2]
DATA_ROOT = pathlib.Path(os.environ.get('SMC_CANONICAL_ROOT', '/mnt/data'))
PARENT_ROOT = REPO_ROOT / 'research/smc_core_expansion_single_policy_20260730'
PARENT_PATH = PARENT_ROOT / 'materialized/main_policy.py'
if not PARENT_PATH.exists():
    subprocess.run([sys.executable, str(PARENT_ROOT / 'materialize.py')], check=True)
OUT = pathlib.Path(os.environ.get('SMC_OUTPUT_DIR', str(DATA_ROOT / 'accepted_delivery_natural_destination_pre2024')))
OUT.mkdir(parents=True, exist_ok=True)

spec = importlib.util.spec_from_file_location('parent_policy', PARENT_PATH)
parent = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(parent)
parent.zips = lambda sym: [DATA_ROOT / f'DS-BYBIT-LINEAR-{sym}-PRE_2024_{y}-CANONICAL-V1.zip' for y in (2021, 2022, 2023)]

SYMS = ('BTCUSDT', 'ETHUSDT')
RISK = 0.03
COSTS = (12.0, 18.0, 24.0)
FIXED_MIN_FUNDING_RESERVE = parent.FIXED_MIN_FUNDING_RESERVE
Y21 = pd.Timestamp('2021-01-01', tz='UTC')
Y22 = pd.Timestamp('2022-01-01', tz='UTC')
Y23 = pd.Timestamp('2023-01-01', tz='UTC')
OFF = pd.Timestamp('2024-01-01', tz='UTC')


def read_frame(sym: str, member: str) -> pd.DataFrame:
    xs = []
    for p in parent.zips(sym):
        with zipfile.ZipFile(p) as zf:
            xs.append(pd.read_parquet(io.BytesIO(zf.read(member))))
    key = 'start_time_ms' if 'start_time_ms' in xs[0].columns else 'timestamp_ms'
    return pd.concat(xs, ignore_index=True).sort_values(key).drop_duplicates(key, keep='last').reset_index(drop=True)


def build_pool_sources(sym: str) -> pd.DataFrame:
    d = read_frame(sym, 'trade_bars/1d.parquet')
    d = d[d.is_complete & d.high.notna() & d.low.notna()].copy().reset_index(drop=True)
    h4 = read_frame(sym, 'trade_bars/4h.parquet')
    h4 = h4[h4.is_complete & h4.high.notna() & h4.low.notna()].copy().reset_index(drop=True)

    rows: list[dict[str, Any]] = []
    # Every completed daily extreme is a newly known one-use external pool.
    for r in d.itertuples(index=False):
        for side, price, suffix in ((1, r.high, 'HIGH'), (-1, r.low, 'LOW')):
            rows.append({
                'pool_id': f'{sym}|DAY|{int(r.start_time_ms)}|{suffix}',
                'symbol': sym, 'pool_side': side, 'price': float(price),
                'available_at_ms': int(r.available_at_ms), 'source_start_ms': int(r.start_time_ms),
                'source_type': 'PRIOR_DAY_EXTREME',
            })

    # Completed UTC Monday-Sunday weekly extremes; available only at next Monday 00:00.
    dt = pd.to_datetime(d.start_time_ms, unit='ms', utc=True)
    week_start = dt.dt.normalize() - pd.to_timedelta(dt.dt.weekday, unit='D')
    d = d.assign(week_start=week_start)
    for ws, g in d.groupby('week_start', sort=True):
        # A full seven-day auction is required; partial year-edge weeks are not invented.
        if len(g) != 7:
            continue
        av = int((ws + pd.Timedelta(days=7)).timestamp() * 1000)
        for side, price, suffix in ((1, g.high.max(), 'HIGH'), (-1, g.low.min(), 'LOW')):
            rows.append({
                'pool_id': f'{sym}|WEEK|{int(ws.timestamp()*1000)}|{suffix}',
                'symbol': sym, 'pool_side': side, 'price': float(price),
                'available_at_ms': av, 'source_start_ms': int(ws.timestamp()*1000),
                'source_type': 'PRIOR_WEEK_EXTREME',
            })

    # Right-confirmed 4h swing: two completed bars on each side. The pool becomes known
    # only after the second right bar is complete.
    hi = h4.high.to_numpy(float)
    lo = h4.low.to_numpy(float)
    for i in range(2, len(h4)-2):
        av = int(h4.available_at_ms.iloc[i+2])
        if hi[i] > max(hi[i-2], hi[i-1], hi[i+1], hi[i+2]):
            rows.append({
                'pool_id': f'{sym}|4H_SWING|{int(h4.start_time_ms.iloc[i])}|HIGH',
                'symbol': sym, 'pool_side': 1, 'price': float(hi[i]),
                'available_at_ms': av, 'source_start_ms': int(h4.start_time_ms.iloc[i]),
                'source_type': 'RIGHT_CONFIRMED_4H_SWING',
            })
        if lo[i] < min(lo[i-2], lo[i-1], lo[i+1], lo[i+2]):
            rows.append({
                'pool_id': f'{sym}|4H_SWING|{int(h4.start_time_ms.iloc[i])}|LOW',
                'symbol': sym, 'pool_side': -1, 'price': float(lo[i]),
                'available_at_ms': av, 'source_start_ms': int(h4.start_time_ms.iloc[i]),
                'source_type': 'RIGHT_CONFIRMED_4H_SWING',
            })
    return pd.DataFrame(rows).sort_values(['available_at_ms','pool_side','price','pool_id']).reset_index(drop=True)


def first_pool_touch(pool: pd.Series, mk, h: pd.DataFrame) -> tuple[int | None, int | None]:
    price = float(pool.price); side = int(pool.pool_side); av = int(pool.available_at_ms)
    ht = h.start_time_ms.to_numpy(np.int64)
    hh = h.high.to_numpy(float); hl = h.low.to_numpy(float)
    j0 = int(np.searchsorted(ht, av, side='left'))
    if j0 >= len(h):
        return None, None
    cond = hh[j0:] >= price if side == 1 else hl[j0:] <= price
    js = np.flatnonzero(cond)
    if not len(js):
        return None, None
    j = j0 + int(js[0])
    a = int(np.searchsorted(mk.mt, int(ht[j]), side='left'))
    b = int(np.searchsorted(mk.mt, int(ht[j]) + 3_600_000, side='left'))
    if b <= a:
        return None, None
    condm = mk.mh[a:b] >= price if side == 1 else mk.ml[a:b] <= price
    ks = np.flatnonzero(condm)
    if not len(ks):
        raise RuntimeError(f'hourly touch without minute touch: {pool.pool_id}')
    k = a + int(ks[0])
    return int(mk.mt[k]), int(mk.mt[k] + 60_000)


def build_pools(sym: str, mk, h: pd.DataFrame) -> pd.DataFrame:
    cached = OUT / f'{sym}_CAUSAL_POOLS.parquet'
    if cached.exists():
        return pd.read_parquet(cached)
    p = build_pool_sources(sym)
    cs, ca = [], []
    for n, r in enumerate(p.itertuples(index=False), 1):
        start, available = first_pool_touch(pd.Series(r._asdict()), mk, h)
        cs.append(start); ca.append(available)
        if n % 500 == 0:
            print(sym, 'pool touch', n, '/', len(p), flush=True)
    p['consumed_start_ms'] = pd.array(cs, dtype='Int64')
    p['consumed_available_ms'] = pd.array(ca, dtype='Int64')
    p.to_parquet(OUT / f'{sym}_CAUSAL_POOLS.parquet', index=False)
    return p


def select_destination(pools: pd.DataFrame, side: int, boundary: float, decision_ms: int) -> pd.Series | None:
    x = pools[(pools.pool_side == side) & (pools.available_at_ms <= decision_ms)].copy()
    x = x[x.consumed_available_ms.isna() | (x.consumed_available_ms > decision_ms)]
    if side == 1:
        x = x[x.price > boundary].sort_values(['price','available_at_ms','source_type','pool_id'])
    else:
        x = x[x.price < boundary].sort_values(['price','available_at_ms','source_type','pool_id'], ascending=[False,True,True,True])
    return None if x.empty else x.iloc[0]


def state_loss_activation(r, h: pd.DataFrame) -> tuple[int | None, int | None]:
    side = int(r.side); boundary = float(r.entry_high if side == 1 else r.entry_low)
    after = h.iloc[int(r.signal_index)+1:]
    idx = after.index[after.close < boundary] if side == 1 else after.index[after.close > boundary]
    if not len(idx):
        return None, None
    i = int(idx[0])
    return i, int(h.loc[i,'available_at_ms']) + 60_000


def candidate(sym: str, r, h: pd.DataFrame, mk, pools: pd.DataFrame) -> dict[str, Any] | None:
    side = int(r.side); decision_ms = int(r.available_at_ms)
    boundary = float(r.entry_high if side == 1 else r.entry_low)
    dest = select_destination(pools, side, boundary, decision_ms)
    if dest is None:
        return None
    entry_i = parent.minute_index(mk, decision_ms + 60_000)
    if entry_i is None:
        return None
    entry_ms = int(mk.mt[entry_i]); entry = float(mk.mo[entry_i])
    target = float(dest.price)
    stop = float(r.low if side == 1 else r.high)
    # Acceptance must still exist at the first executable observation and the full event
    # displacement must lie between entry and invalidation.
    if side * (entry - boundary) <= 0 or side * (entry - stop) <= 0 or side * (target - entry) <= 0:
        return None
    cstart = None if pd.isna(dest.consumed_start_ms) else int(dest.consumed_start_ms)
    if cstart is not None and cstart < entry_ms:
        return None
    latest_funding = float(r.funding_rate) if pd.notna(r.funding_rate) else 0.0
    funding_reserve = max(FIXED_MIN_FUNDING_RESERVE, max(0.0, side * latest_funding))
    # This is not a minimum-R filter. It only rejects a completed scenario whose entire
    # observable destination move cannot pay the unavoidable account costs.
    fee24 = 24.0 / 20_000.0
    max_profit_per_unit = side * (target-entry)
    unavoidable_per_unit = fee24 * (entry+target) + funding_reserve * entry
    if max_profit_per_unit <= unavoidable_per_unit:
        return None

    _, state_ms = state_loss_activation(r, h)
    state_i = parent.minute_index(mk, state_ms) if state_ms is not None else None
    pre_end = state_i-1 if state_i is not None else len(mk.mt)-1
    hit = parent.first_barrier(mk, entry_i, pre_end, side, stop, target)
    if hit is not None:
        xi, xp, reason = hit
        reason = 'natural_destination' if reason == 'target' else reason
    elif state_i is not None:
        op = float(mk.mo[state_i])
        adverse_gap = op <= stop if side == 1 else op >= stop
        favorable_gap = op >= target if side == 1 else op <= target
        if adverse_gap:
            xi, xp, reason = state_i, op, 'stop_gap_before_state_exit'
        elif favorable_gap:
            xi, xp, reason = state_i, target, 'natural_destination_gap_before_state_exit'
        else:
            xi, xp, reason = state_i, op, 'accepted_boundary_state_loss'
    else:
        xi, xp, reason = len(mk.mt)-1, float(mk.mc[-1]), 'evaluation_mark'

    exit_ms = int(mk.mt[xi])
    return {
        'event_key': f'{sym}|{entry_ms}|{side}', 'symbol': sym, 'side': side,
        'signal_ms': decision_ms, 'entry_ms': entry_ms, 'entry_time': pd.to_datetime(entry_ms,unit='ms',utc=True),
        'entry': entry, 'boundary': boundary, 'stop': stop, 'target': target,
        'target_pool_id': str(dest.pool_id), 'target_pool_type': str(dest.source_type),
        'target_pool_available_ms': int(dest.available_at_ms),
        'target_pool_consumed_start_ms': cstart,
        'state_loss_activation_ms': state_ms,
        'exit_ms': exit_ms, 'exit': float(xp), 'exit_reason': reason,
        'gross': float(side * (float(xp)/entry - 1.0)),
        'funding': parent.funding(mk, entry_ms, exit_ms, side),
        'volume_z': float(r.volume_z168), 'funding_z_signed': float(r.funding_z90_signed),
        'breakout_atr': float(r.breakout_atr), 'funding_reserve': funding_reserve,
        'gross_destination_r': float(abs(target-entry)/abs(entry-stop)),
        'used_exit_ms': exit_ms,
    }


def build_events(markets, hourly, raw, pools_by_sym) -> tuple[pd.DataFrame, dict[str,int]]:
    rows=[]; reasons={'raw':len(raw),'no_candidate':0}
    for sym,g in raw.groupby('symbol',sort=False):
        for r in g.itertuples(index=False):
            x=candidate(sym,r,hourly[sym],markets[sym],pools_by_sym[sym])
            if x is None:
                reasons['no_candidate'] += 1
            else:
                rows.append(x)
    ev=pd.DataFrame(rows).sort_values(['entry_ms','symbol']).reset_index(drop=True)
    if len(ev): ev['year']=ev.entry_time.dt.year
    return ev,reasons


def outcome(r, nav: float, cost_bps: float, boundary_ms: int | None, markets) -> dict[str,Any]:
    entry=float(r.entry); stop=float(r.stop); side=int(r.side)
    fee=cost_bps/20_000.0
    stop_per_unit=abs(entry-stop)+fee*(entry+stop)+float(r.funding_reserve)*entry
    qty=nav*RISK/max(stop_per_unit,1e-12)
    exit_px=float(r.exit); exit_ms=int(r.exit_ms); reason=str(r.exit_reason)
    fd=float(r.funding)
    if boundary_ms is not None and exit_ms >= boundary_ms:
        mk=markets[str(r.symbol)]
        i=int(np.searchsorted(mk.mt,boundary_ms,side='left'))-1
        i=max(i,0); exit_px=float(mk.mc[i]); exit_ms=boundary_ms; reason='boundary_mark'
        fd=parent.funding(mk,int(r.entry_ms),exit_ms,side)
    gross_pnl=qty*side*(exit_px-entry)
    funding_pnl=qty*entry*fd
    pnl=gross_pnl+funding_pnl-qty*fee*(entry+exit_px)
    return {'quantity':qty,'leverage':qty*entry/nav,'pnl':pnl,'account_return':pnl/nav,
            'used_exit_ms':exit_ms,'used_exit':exit_px,'used_reason':reason,'used_funding':fd}


def replay(events, markets, start, end, cost_bps, exclude=None):
    excluded=set(exclude or []); a=int(start.timestamp()*1000); z=int(end.timestamp()*1000)
    x=events[(events.entry_ms>=a)&(events.entry_ms<z)&(~events.event_key.isin(excluded))].copy()
    x=x.sort_values(['entry_ms','volume_z','funding_z_signed','symbol'],ascending=[True,False,True,True])
    nav=10_000.0; free=-1; ledger=[]
    for t,g in x.groupby('entry_ms',sort=True):
        if int(t)<=free: continue
        r=g.iloc[0]; o=outcome(r,nav,cost_bps,z,markets); before=nav; nav=max(0.0,nav+o['pnl'])
        ledger.append({**r.to_dict(),**o,'nav_before':before,'nav_after':nav,'pnl':nav-before})
        free=int(o['used_exit_ms'])
        if free>=z: break
    return pd.DataFrame(ledger),nav


def nav_at(ledger,markets,boundary,cost):
    if ledger.empty:return 10_000.0
    ms=int(boundary.timestamp()*1000)
    past=ledger[ledger.used_exit_ms<ms]
    nav=float(past.nav_after.iloc[-1]) if len(past) else 10_000.0
    op=ledger[(ledger.entry_ms<ms)&(ledger.used_exit_ms>=ms)]
    if len(op):
        r=op.iloc[-1]; o=outcome(r,float(r.nav_before),cost,ms,markets); nav=float(r.nav_before)+o['pnl']
    return nav


def metrics(ledger,nav,markets,start,end,cost):
    if ledger.empty:
        return {'end_nav':10000.0,'multiple':1.0,'trades':0,'pf':0.0,'median':0.0,'mean':0.0,'g_daily':0.0,'daily_mark_mdd':0.0}
    wins=ledger.loc[ledger.pnl>0,'pnl']; loss=-ledger.loc[ledger.pnl<0,'pnl'].sum()
    dates=pd.date_range(start,end,freq='D',tz='UTC')
    daily=pd.Series([nav_at(ledger,markets,d,cost) for d in dates])
    closed=pd.concat([pd.Series([10_000.0]),ledger.nav_after.reset_index(drop=True)])
    return {
        'end_nav':float(nav),'multiple':float(nav/10000.0),'trades':int(len(ledger)),
        'pf':float(wins.sum()/loss) if loss>0 else None,'median':float(ledger.account_return.median()),
        'mean':float(ledger.account_return.mean()),'g_daily':float((nav/10000.0)**(1/max((end-start).days,1))-1),
        'daily_mark_mdd':float((1-daily/daily.cummax()).max()),'trade_close_mdd':float((1-closed/closed.cummax()).max()),
        'positive_trades':int((ledger.pnl>0).sum()),'negative_trades':int((ledger.pnl<0).sum()),
        'median_hold_hours':float(((ledger.used_exit_ms-ledger.entry_ms)/3_600_000).median()),
        'top5_positive_share':float(wins.nlargest(5).sum()/wins.sum()) if wins.sum()>0 else None,
        'max_leverage':float(ledger.leverage.max()),'median_leverage':float(ledger.leverage.median()),
        'min_trade_return':float(ledger.account_return.min()),
        'planned_loss_exceed_count':int((ledger.account_return < -RISK-1e-9).sum()),
        'exit_reasons':ledger.used_reason.value_counts().to_dict(),
        'target_pool_types':ledger.target_pool_type.value_counts().to_dict(),
        'gross_destination_r':{
            'median':float(ledger.gross_destination_r.median()),
            'p10':float(ledger.gross_destination_r.quantile(.1)),
            'p90':float(ledger.gross_destination_r.quantile(.9)),
        },
    }


def evaluate(events,markets,start,end,cost):
    led,nav=replay(events,markets,start,end,cost); m=metrics(led,nav,markets,start,end,cost)
    winners=led[led.pnl>0]
    n=min(len(winners),math.ceil(.1*len(led))) if len(led) else 0
    keys=set(winners.nlargest(n,'pnl').event_key.astype(str)) if n else set()
    wl,wn=replay(events,markets,start,end,cost,keys)
    m['winner_removed']={**metrics(wl,wn,markets,start,end,cost),'removed':n,'keys':sorted(keys)}
    return m,led


def pre2024_gate(m22,m23):
    return bool(m22['trades']>=30 and m23['trades']>=30 and m22['multiple']>1 and m23['multiple']>1
                and m22['winner_removed']['multiple']>1 and m23['winner_removed']['multiple']>1)


def main():
    markets,hourly,raw=parent.build_raw()
    pools={s:build_pools(s,markets[s],hourly[s]) for s in SYMS}
    events,filter_counts=build_events(markets,hourly,raw,pools)
    events.to_parquet(OUT/'EVENTS.parquet',index=False)
    print('EVENT_COUNTS',events.groupby([events.entry_time.dt.year,'symbol','side']).size().to_dict(),flush=True)
    results={'schema_version':1,'claim_id':'CLM-20260731-ACCEPTED-DELIVERY-NATURAL-DESTINATION-001',
             'risk_fraction':RISK,'parent_thresholds':{'volume_z168':parent.VOL_THRESHOLD,'funding_z90_signed_max':parent.FUNDING_CROWDING_Q75},
             'parent_raw_counts':raw.groupby([raw.decision_time.dt.year,'symbol','side']).size().rename('count').reset_index().to_dict('records'),
             'filter_counts':filter_counts,'event_counts':events.groupby([events.entry_time.dt.year,'symbol','side']).size().rename('count').reset_index().to_dict('records'),
             'periods':{}}
    for cost in COSTS:
        ckey=str(int(cost)); results['periods'][ckey]={}
        for label,a,b in [('2021_DIAGNOSTIC',Y21,Y22),('2022_FORWARD',Y22,Y23),('2023_CONFIRMATION',Y23,OFF),('2022_2023',Y22,OFF)]:
            m,led=evaluate(events,markets,a,b,cost); results['periods'][ckey][label]=m
            led.to_csv(OUT/f'LEDGER_{label}_{int(cost)}BP.csv',index=False)
            print('RESULT',cost,label,json.dumps(m,sort_keys=True,default=str),flush=True)
    m22=results['periods']['24']['2022_FORWARD'];m23=results['periods']['24']['2023_CONFIRMATION']
    results['pre2024_gate_pass']=pre2024_gate(m22,m23)
    results['decision']='OPEN_OFFICIAL_2024H1' if results['pre2024_gate_pass'] else 'RETIRE_EXACT_NATURAL_DESTINATION_LIFECYCLE_PRE2024'
    (OUT/'RESULT.json').write_text(json.dumps(results,indent=2,default=lambda x: list(x) if isinstance(x,tuple) else str(x))+'\n')
    print('DECISION',results['decision'])

if __name__=='__main__':main()
