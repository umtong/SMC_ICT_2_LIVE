import importlib.util, pathlib, pandas as pd, numpy as np, json
p=pathlib.Path(__file__).resolve().parent/'natural_destination_audit.py'
s=importlib.util.spec_from_file_location('nda',p); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)
markets,hourly,raw=m.parent.build_raw()
pools={s:pd.read_parquet(m.OUT/f'{s}_CAUSAL_POOLS.parquet') for s in m.SYMS}
rows=[]
for r in raw.itertuples(index=False):
    sym=str(r.symbol); side=int(r.side); h=hourly[sym]; mk=markets[sym]
    decision=int(r.available_at_ms); boundary=float(r.entry_high if side==1 else r.entry_low)
    d=m.select_destination(pools[sym],side,boundary,decision)
    base={'symbol':sym,'side':side,'decision_time':pd.to_datetime(decision,unit='ms',utc=True),'boundary':boundary,'volume_z':float(r.volume_z168),'funding_z_signed':float(r.funding_z90_signed)}
    if d is None:
        rows.append({**base,'skip_reason':'NO_CAUSAL_LIVE_DIRECTIONAL_DESTINATION'})
        continue
    entry_i=m.parent.minute_index(mk,decision+60_000)
    if entry_i is None:
        rows.append({**base,'skip_reason':'NO_LATER_EXECUTABLE_MINUTE','target':float(d.price),'target_pool_type':str(d.source_type)})
        continue
    entry_ms=int(mk.mt[entry_i]); entry=float(mk.mo[entry_i]); target=float(d.price); stop=float(r.low if side==1 else r.high)
    common={**base,'entry_time':pd.to_datetime(entry_ms,unit='ms',utc=True),'entry':entry,'stop':stop,'target':target,'target_pool_type':str(d.source_type),'target_pool_id':str(d.pool_id)}
    if side*(entry-boundary)<=0:
        rows.append({**common,'skip_reason':'ACCEPTED_OUTSIDE_STATE_LOST_BEFORE_ENTRY'}); continue
    if side*(entry-stop)<=0:
        rows.append({**common,'skip_reason':'EVENT_EXTREME_INVALID_BEFORE_ENTRY'}); continue
    if side*(target-entry)<=0:
        rows.append({**common,'skip_reason':'DESTINATION_ALREADY_BEHIND_ENTRY'}); continue
    cstart=None if pd.isna(d.consumed_start_ms) else int(d.consumed_start_ms)
    if cstart is not None and cstart<entry_ms:
        rows.append({**common,'skip_reason':'DESTINATION_CONSUMED_BEFORE_ENTRY'}); continue
    latest=float(r.funding_rate) if pd.notna(r.funding_rate) else 0.0
    reserve=max(m.FIXED_MIN_FUNDING_RESERVE,max(0.0,side*latest)); fee=24/20000
    if side*(target-entry)<=fee*(entry+target)+reserve*entry:
        rows.append({**common,'skip_reason':'DESTINATION_MOVE_CANNOT_PAY_UNAVOIDABLE_COST'}); continue
    rows.append({**common,'skip_reason':'ELIGIBLE'})

df=pd.DataFrame(rows)
df.to_csv(m.OUT/'CANDIDATE_DECISIONS.csv',index=False)
print(df.skip_reason.value_counts().to_string())
# Compact counterexample evidence: earliest and latest example per non-eligible reason.
ce=[]
for reason,g in df[df.skip_reason!='ELIGIBLE'].groupby('skip_reason'):
    ce.extend([g.sort_values('decision_time').iloc[0],g.sort_values('decision_time').iloc[-1]])
pd.DataFrame(ce).drop_duplicates(['symbol','side','decision_time','skip_reason']).to_csv(m.OUT/'COUNTEREXAMPLES.csv',index=False)
# Trace evidence from actually executed 24bp ledgers: representative destination, state-loss, and stop cases.
all_led=[]
for period in ('2022_FORWARD','2023_CONFIRMATION'):
    x=pd.read_csv(m.OUT/f'LEDGER_{period}_24BP.csv')
    x['period']=period
    for reason,g in x.groupby('used_reason'):
        # Largest positive/most adverse plus median-return example, without cherry-picking for metrics.
        idx={g.account_return.idxmax(),g.account_return.idxmin(),(g.account_return-g.account_return.median()).abs().idxmin()}
        all_led.append(x.loc[sorted(idx)])
trace=pd.concat(all_led,ignore_index=True).drop_duplicates('event_key').sort_values(['period','entry_ms'])
cols=['period','event_key','entry_time','symbol','side','signal_ms','entry_ms','entry','boundary','stop','target','target_pool_id','target_pool_type','target_pool_available_ms','target_pool_consumed_start_ms','state_loss_activation_ms','used_exit_ms','used_exit','used_reason','gross_destination_r','funding_reserve','account_return','pnl','nav_before','nav_after','leverage','volume_z','funding_z_signed']
trace[cols].to_csv(m.OUT/'TRACE_SAMPLE.csv',index=False)
print('counterexamples',len(pd.read_csv(m.OUT/'COUNTEREXAMPLES.csv')),'traces',len(trace))
